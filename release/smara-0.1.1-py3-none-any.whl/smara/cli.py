"""Smara CLI: Claude Code inspired autonomous developer agent for terminal and desktop."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import sqlite3
import subprocess
import sys
import time
import webbrowser
from pathlib import Path
from typing import Any
from urllib.parse import quote, urlparse

import httpx

from .tui import TerminalRenderer


# ============================================================================
# Compatibility / Legacy Cloud Helpers
# ============================================================================

def _default_browser_auth_url(api_url: str, device_code: str) -> str:
    """Open the canonical Smara root for browser device approval."""
    base = api_url.rstrip("/")
    encoded = quote(device_code, safe="")
    if base.endswith("/smara-api"):
        return f"{base.removesuffix('/smara-api')}/?cli_device={encoded}"
    return f"{base}/?cli_device={encoded}"


class _TerminalUI(TerminalRenderer):
    """Compatibility alias for legacy tests."""
    def banner(self, *, api_url: str, session: str, workspace: str, authenticated: bool) -> None:
        self.print_banner(model_label="Cloud", workspace_path=workspace, zero_friction=False)

    def tool_call(self, name: str) -> None:
        self.print_tool_start("tool", name)

    def tool_result(self, name: str, ok: bool) -> None:
        self.print_tool_result("tool", ok)

    def phase(self, name: str) -> None:
        print(f"  · {name}")

    def status(self, label: str) -> None:
        print(f"  ↳ {label}")

    def done(self, *, total_ms: int | None = None, tools_used: int | None = None) -> None:
        parts = []
        if total_ms is not None:
            parts.append(f"{total_ms} ms")
        if tools_used:
            parts.append(f"{tools_used} tools")
        if parts:
            print(f"  · {' · '.join(parts)}")

    def error(self, message: str) -> None:
        self.print_error(message)

    def prompt(self) -> str:
        return "you ❯ "


def _stream_chat(
    client: httpx.Client,
    *,
    message: str,
    workspace: str,
    conversation_id: str,
    model_profile: str | None = None,
    ui: _TerminalUI | None = None,
) -> str:
    ui = ui or _TerminalUI(plain=True)
    payload = {"message": message, "workspace_id": workspace, "conversation_id": conversation_id}
    if model_profile:
        payload["model_profile"] = model_profile
    final_text = ""
    event_name = "message"
    done_data: dict[str, Any] = {}
    try:
        with client.stream("POST", "/v1/chat/stream", json=payload, headers={"Accept": "text/event-stream"}) as response:
            if response.status_code >= 400:
                raise RuntimeError(f"{response.status_code}: chat stream unavailable")
            for line in response.iter_lines():
                if not line:
                    continue
                if line.startswith("event: "):
                    event_name = line.removeprefix("event: ")
                    continue
                if not line.startswith("data: "):
                    continue
                try:
                    data = json.loads(line.removeprefix("data: "))
                except json.JSONDecodeError:
                    continue
                payload_type = data.get("type")
                if isinstance(payload_type, str) and payload_type:
                    event_name = payload_type
                if event_name == "token":
                    text = str(data.get("text", ""))
                    print(text, end="", flush=True)
                    final_text += text
                elif event_name == "tool_call":
                    ui.tool_call(str(data.get("name", "unknown")))
                elif event_name == "tool_result":
                    ui.tool_result(str(data.get("name", "unknown")), bool(data.get("ok")))
                elif event_name == "phase":
                    ui.phase(str(data.get("phase", "working")))
                elif event_name == "status":
                    ui.status(str(data.get("label", data.get("message", "working"))))
                elif event_name == "done":
                    done_data = data
                elif event_name == "error":
                    raise RuntimeError(str(data.get("message", "Smara chat failed.")))
    except (httpx.HTTPError, json.JSONDecodeError) as exc:
        raise RuntimeError("Smara chat stream disconnected; retry the turn.") from exc
    if not final_text.strip():
        raise RuntimeError("Smara returned no answer. Check the hosted model provider and try again.")
    ui.done(
        total_ms=int(done_data["total_ms"]) if str(done_data.get("total_ms", "")).isdigit() else None,
        tools_used=int(done_data["tools_used"]) if str(done_data.get("tools_used", "")).isdigit() else None,
    )
    print()
    return final_text


# ============================================================================
# Local Autonomous Engine & State Management
# ============================================================================

def _desktop_state_path() -> Path:
    env_path = os.getenv("SMARA_DESKTOP_STATE")
    if env_path:
        return Path(env_path)
    appdata = Path(os.getenv("APPDATA", Path.home() / ".config"))
    return appdata / "Smara" / "desktop.json"


def _load_local_profiles() -> tuple[list[dict[str, Any]], str, dict[str, str]]:
    """Load local model profiles, active model ID, and credentials from desktop.json / credentials.json."""
    state_file = _desktop_state_path()
    profiles: list[dict[str, Any]] = []
    active_id = "grok"
    credentials: dict[str, str] = {}

    # Load credentials file
    cred_file = state_file.parent / "credentials.json"
    if cred_file.exists():
        try:
            credentials = json.loads(cred_file.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            pass

    if state_file.exists():
        try:
            state = json.loads(state_file.read_text(encoding="utf-8"))
            profiles = state.get("model_profiles", [])
            active_id = state.get("active_model", active_id)
        except (OSError, ValueError):
            pass

    ui_file = state_file.parent / "desktop-ui.json"
    if ui_file.exists():
        try:
            ui_state = json.loads(ui_file.read_text(encoding="utf-8"))
            if ui_state.get("local_model_profiles") and not profiles:
                profiles = ui_state["local_model_profiles"]
            if ui_state.get("model_profile"):
                active_id = ui_state["model_profile"].removeprefix("local:")
        except (OSError, ValueError):
            pass

    if not profiles:
        profiles = [
            {"id": "grok", "label": "Grok-3 Mini", "base_url": "https://api.x.ai/v1", "model": "grok-3-mini", "auth_header": "authorization"},
            {"id": "sarvam", "label": "Sarvam 105B", "base_url": "https://api.sarvam.ai/v2", "model": "sarvam-105b", "auth_header": "api-subscription-key"},
            {"id": "ollama", "label": "Ollama Local", "base_url": "http://localhost:11434/v1", "model": "llama3.3", "auth_header": "authorization"},
            {"id": "openrouter", "label": "OpenRouter", "base_url": "https://openrouter.ai/api/v1", "model": "anthropic/claude-3.5-sonnet", "auth_header": "authorization"},
        ]

    # Sarvam retired the old GLM aliases.  Migrate stale Desktop/CLI profile
    # state in memory so a persisted profile cannot silently call a deprecated
    # model; the user's credential remains untouched in the vault.
    for profile in profiles:
        if str(profile.get("id", "")).lower() != "sarvam":
            continue
        model = str(profile.get("model") or "").lower().replace("-", "").replace(".", "")
        if model in {"glm52", "glm53", "glm53flash"}:
            profile["model"] = "sarvam-105b"
            profile["label"] = "Sarvam 105B"
        base_url = str(profile.get("base_url") or "")
        if "api.sarvam.ai" in base_url and "/v1" in base_url and "/v2" not in base_url:
            profile["base_url"] = "https://api.sarvam.ai/v2"

    return profiles, active_id, credentials


def _resolve_profile_key(profile: dict[str, Any], credentials: dict[str, Any]) -> str:
    pid = profile.get("id", "").lower()
    env_keys = {
        "grok": ["SMARA_MODEL_GROK_API_KEY", "GROK_API_KEY", "XAI_API_KEY"],
        "sarvam": ["SMARA_MODEL_SARVAM_API_KEY", "SARVAM_API_KEY"],
        "openrouter": ["SMARA_MODEL_OPENROUTER_API_KEY", "OPENROUTER_API_KEY"],
        "ollama": ["OLLAMA_API_KEY"],
    }
    for env_name in env_keys.get(pid, [f"SMARA_MODEL_{pid.upper()}_API_KEY"]):
        val = os.getenv(env_name)
        if val:
            return val

    # Try protected credentials via desktop_executor first
    cred_keys = [
        f"SMARA_MODEL_{pid.upper()}_API_KEY",
        f"model_api_key_{pid}",
        f"{pid.upper()}_API_KEY",
        f"{pid}_api_key",
    ]
    try:
        from .desktop_executor import resolve_local_credential
        for k in cred_keys:
            try:
                resolved = resolve_local_credential(k)
                if resolved and isinstance(resolved, str):
                    return resolved
            except Exception:
                pass
    except ImportError:
        pass

    # Fallback to direct credentials store lookup
    for k in cred_keys:
        for lookup in (k, k.lower(), k.upper()):
            if lookup in credentials:
                val = credentials[lookup]
                if isinstance(val, str) and val:
                    return val
                if isinstance(val, dict) and "protected" in val:
                    try:
                        from .desktop_executor import _unprotect_windows
                        dec = _unprotect_windows(val["protected"])
                        if dec:
                            return dec
                    except Exception:
                        pass

    return "ollama-local" if pid == "ollama" else ""


def _strip_thinking(text: str) -> str:
    """Remove internal reasoning scratchpad or <think> tags."""
    res = re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL)
    res = re.sub(r"^<think>.*", "", res, flags=re.DOTALL)
    return res.strip()


class LocalAutonomousEngine:
    """Executes Claude Code inspired autonomous reasoning with local capabilities."""

    def __init__(self, workspace_root: Path | None = None, tui: TerminalRenderer | None = None):
        self.workspace = (workspace_root or Path.cwd()).resolve()
        self.tui = tui or TerminalRenderer()
        self.profiles, self.active_id, self.credentials = _load_local_profiles()
        self.history: list[dict[str, str]] = []

    @property
    def active_profile(self) -> dict[str, Any]:
        for p in self.profiles:
            if p.get("id") == self.active_id:
                return p
        return self.profiles[0]

    def set_active_model(self, model_id: str) -> bool:
        needle = model_id.lower().strip()
        for p in self.profiles:
            if p.get("id", "").lower() == needle or needle in p.get("label", "").lower():
                self.active_id = p["id"]
                return True
        return False

    def _execute_raw_capability(self, capability: str, payload: dict[str, Any], title: str = "") -> dict[str, Any]:
        """Directly run local capabilities (AST graph, live search, PDF/DOCX, terminal, dynamic tools)."""
        self.tui.print_tool_start(capability, title or capability)
        start_t = time.time()
        result_data: dict[str, Any] = {}

        try:
            if capability == "local_graph":
                from .code_graph import CodePropertyGraph
                operation = payload.get("operation", "inspect_symbol")
                symbol = payload.get("symbol", "")
                
                # Check candidate paths
                graph = CodePropertyGraph(self.workspace)
                graph.index()
                if len(graph.symbols) == 0:
                    candidates = [Path.cwd(), Path(__file__).resolve().parent.parent.parent]
                    for c in candidates:
                        if c.exists():
                            g = CodePropertyGraph(c)
                            g.index()
                            if len(g.symbols) > 0:
                                graph = g
                                break
                
                if operation == "inspect_symbol":
                    res = graph.inspect_symbol(symbol)
                elif operation == "blast_radius":
                    res = graph.blast_radius(symbol)
                elif operation == "find_references":
                    res = graph.find_references(symbol)
                else:
                    res = graph.inspect_symbol(symbol)
                
                if operation == "inspect_symbol" and isinstance(res, dict):
                    res["blast_radius"] = graph.blast_radius(symbol)
                
                result_data = {"action": "local_graph", "operation": operation, "symbol": symbol, "result": res}
                summary = f"Indexed {len(graph.symbols)} symbols; inspected {symbol}" if res else f"Symbol '{symbol}' not found"
                self.tui.print_tool_result(capability, res is not None, summary)

            elif capability == "local_integration":
                from .desktop_executor import resolve_local_credential
                from .desktop_integrations import execute_local_integration
                
                def _cred_resolver(keys: list[str]) -> dict[str, str]:
                    return {k: resolve_local_credential(k) for k in keys}
                
                res_str = execute_local_integration(payload, _cred_resolver)
                result_data = json.loads(res_str)
                count = len(result_data.get("results", []))
                self.tui.print_tool_result(capability, True, f"Found {count} live web sources")

            elif capability == "local_file_write":
                op = payload.get("operation", "write")
                if op == "compile_report":
                    from .deep_research import DeepResearchEngine
                    d_engine = DeepResearchEngine(self.workspace)
                    topic = payload.get("topic", "Market Analysis")
                    vectors = d_engine.fan_out_research_vectors(topic)
                    sources = d_engine.retrieve_multi_vector_sources(vectors)
                    analysis = d_engine.synthesize_market_analysis(topic, sources)
                    report_path = d_engine.generate_executive_report(topic, analysis)
                    result_data = {"action": "local_file_write", "operation": "compile_report", "report_path": str(report_path)}
                    self.tui.print_tool_result(capability, True, f"Saved executive report to {report_path}")
                else:
                    from .desktop_executor import _write_file_unlocked
                    res_str = _write_file_unlocked(payload, [self.workspace])
                    result_data = json.loads(res_str)
                    fname = result_data.get("file_name", "file")
                    bytes_w = result_data.get("bytes_written", 0)
                    self.tui.print_tool_result(capability, True, f"Saved {fname} ({bytes_w} bytes)")

            elif capability == "local_file_read":
                from .path_resolver import locate_resource, read_whole_file, inspect_discovered_folder
                path_arg = payload.get("path") or payload.get("folder") or ""
                located = locate_resource(path_arg, [self.workspace])
                if located:
                    if located.is_dir():
                        info = inspect_discovered_folder(located)
                        info["action"] = "local_file_read"
                        result_data = info
                        summary = f"Located and inspected folder '{located.name}' ({info['total_items']} items) at {located}"
                        self.tui.print_tool_result(capability, True, summary)
                    else:
                        info = read_whole_file(located)
                        result_data = info
                        summary = f"Read whole file '{located.name}' ({info['bytes_read']} bytes, {info['total_lines']} lines) at {located}"
                        self.tui.print_tool_result(capability, True, summary)
                else:
                    from .desktop_executor import _workspace_inspect
                    res_str = _workspace_inspect(payload, [self.workspace])
                    result_data = json.loads(res_str)
                    self.tui.print_tool_result(capability, True, "Read workspace")

            elif capability == "local_terminal":
                from .desktop_executor import _terminal
                res_str = _terminal(payload, [self.workspace], {})
                result_data = json.loads(res_str)
                out = result_data.get("output", "")
                self.tui.print_tool_result(capability, result_data.get("returncode", 0) == 0, f"Output {len(out)} chars")

            elif capability == "dynamic_tool_synthesize":
                from .tool_synthesis import DynamicToolSynthesizer
                synth = DynamicToolSynthesizer(self.workspace)
                res = synth.synthesize_tool(
                    name=payload.get("name", "custom_tool"),
                    description=payload.get("description", ""),
                    code=payload.get("code", ""),
                    parameters=payload.get("parameters"),
                    sample_payload=payload.get("sample_payload"),
                )
                result_data = res
                self.tui.print_tool_result(capability, True, f"Synthesized & verified tool '{res['name']}'")

            elif capability == "dynamic_tool_exec":
                from .tool_synthesis import DynamicToolSynthesizer
                synth = DynamicToolSynthesizer(self.workspace)
                t_name = payload.get("name") or payload.get("tool", "")
                t_args = payload.get("payload") or payload.get("arguments", {})
                res = synth.execute_dynamic_tool(t_name, t_args)
                result_data = res
                ok = res.get("status") == "success"
                self.tui.print_tool_result(capability, ok, f"Executed dynamic tool '{t_name}'")

            elif capability == "dynamic_tool_list":
                from .tool_synthesis import DynamicToolSynthesizer
                synth = DynamicToolSynthesizer(self.workspace)
                tools = synth.list_dynamic_tools()
                result_data = {"action": "dynamic_tool_list", "tools": tools}
                self.tui.print_tool_result(capability, True, f"Found {len(tools)} dynamic tools")

            elif capability == "deep_research":
                from .deep_research import DeepResearchEngine
                d_engine = DeepResearchEngine(self.workspace)
                topic = payload.get("topic") or payload.get("query") or "Market Analysis"
                op = payload.get("operation", "run_pipeline")
                if op == "fan_out_queries":
                    vectors = d_engine.fan_out_research_vectors(topic)
                    result_data = {"action": "deep_research", "operation": op, "vectors": vectors}
                    self.tui.print_tool_result(capability, True, f"Generated {len(vectors)} research vectors")
                elif op == "retrieve_sources":
                    vectors = d_engine.fan_out_research_vectors(topic)
                    sources = d_engine.retrieve_multi_vector_sources(vectors)
                    result_data = {"action": "deep_research", "operation": op, "sources": sources}
                    self.tui.print_tool_result(capability, True, f"Retrieved {len(sources)} sources")
                elif op == "scrape_primary_evidence":
                    vectors = d_engine.fan_out_research_vectors(topic)
                    sources = d_engine.retrieve_multi_vector_sources(vectors)
                    scraped = d_engine.scrape_primary_evidence(sources)
                    result_data = {"action": "deep_research", "operation": op, "scraped": scraped}
                    self.tui.print_tool_result(capability, True, f"Scraped {len(scraped)} primary sources")
                elif op == "synthesize_analysis":
                    vectors = d_engine.fan_out_research_vectors(topic)
                    sources = d_engine.retrieve_multi_vector_sources(vectors)
                    analysis = d_engine.synthesize_market_analysis(topic, sources)
                    result_data = {"action": "deep_research", "operation": op, "analysis": analysis}
                    self.tui.print_tool_result(capability, True, f"Synthesized competitive matrix ({len(analysis['competitive_matrix'])} tiers)")
                else:
                    res = d_engine.run_full_pipeline(topic)
                    result_data = res
                    self.tui.print_tool_result(capability, True, f"Market report saved to {res['report_path']}")

            else:
                result_data = {"error": f"Unknown capability: {capability}"}
                self.tui.print_tool_result(capability, False, f"Unknown capability {capability}")

        except Exception as exc:
            result_data = {"error": str(exc)}
            self.tui.print_tool_result(capability, False, str(exc))

        return result_data

    def execute_capability(self, capability: str, payload: dict[str, Any], title: str = "") -> dict[str, Any]:
        """Execute capability through the Reflect-Act-Verify (RAV) self-healing loop."""
        from .self_healing import SelfHealingEngine
        healer = SelfHealingEngine(max_attempts=3)

        def _on_reflection(thought_text: str) -> None:
            self.tui.print_thought(f"RAV Reflection: {thought_text}")

        res = healer.execute_with_healing(
            executor_fn=self._execute_raw_capability,
            capability=capability,
            initial_payload=payload,
            title=title,
            on_reflection=_on_reflection,
        )
        if res.get("_self_healed"):
            self.tui.print_progress(f"Self-healed on attempt {res.get('_attempts')}")
        return res

    def _run_shared_local_turn(self, user_prompt: str, profile: dict[str, Any], api_key: str) -> str:
        """Execute autonomous turn with surgical tools, AST intelligence, and live TUI rendering."""
        from .autonomous_agent import SmaraAutonomousAgent
        started_at = time.time()

        def on_progress(event_type: str, data: dict[str, Any]) -> None:
            if event_type == "thought":
                thought = data.get("thought", "").strip()
                if thought:
                    clean_th = _strip_thinking(thought)
                    if clean_th:
                        first_thought = clean_th.split("\n\n")[0][:220]
                        self.tui.print_thought(first_thought)
            elif event_type == "tool_start":
                tool = data.get("tool", "")
                args = data.get("args", {})
                target_path = args.get("path") or args.get("file_path") or ""
                if tool == "file_read":
                    offset = args.get("offset", 1)
                    limit = args.get("limit", 100)
                    detail = f"{target_path} (L{offset}-{offset + limit})"
                elif tool in ("file_write", "file_edit"):
                    detail = target_path
                elif tool == "bash":
                    cmd = args.get("command", "")
                    detail = f"{cmd[:60]}..." if len(cmd) > 60 else cmd
                elif tool == "list_directory":
                    detail = f"{args.get('path', '.')}"
                elif tool == "search_files":
                    detail = f"query='{args.get('query', '')}'"
                elif tool == "code_graph":
                    detail = f"{args.get('operation', '')} symbol='{args.get('symbol', '')}'"
                elif tool in ("web_search", "deep_research"):
                    detail = f"query='{args.get('query', '')}'"
                elif tool == "python_execute":
                    code = args.get("code", "")
                    detail = f"{code[:50]}..." if len(code) > 50 else code
                else:
                    detail = str(args)[:60]
                self.tui.print_tool_start(tool, detail)
            elif event_type == "tool_end":
                tool = data.get("tool", "")
                obs = data.get("observation", "")
                ok = not ("Error" in obs or "Failed" in obs or "Traceback" in obs)
                first_line = obs.strip().splitlines()[0] if obs.strip() else "Done"
                if len(first_line) > 100:
                    first_line = first_line[:97] + "..."
                self.tui.print_tool_result(tool, ok, first_line)

        agent = SmaraAutonomousAgent(
            api_key=api_key,
            model=str(profile.get("model") or "sarvam-2b"),
            base_url=str(profile.get("base_url") or "https://api.sarvam.ai/v1"),
            # The interactive CLI is the primary legacy engine.  "worker"
            # was never an admitted profile and silently exposed every schema.
            profile="full",
            auth_header=str(profile.get("auth_header") or "authorization"),
            workspace_root=self.workspace,
            on_progress=on_progress,
        )

        try:
            result = agent.run(
                task=user_prompt,
                max_iterations=25,
                context_history=self.history[-16:],
            )
        except Exception as exc:
            self.tui.print_error(f"Execution failed: {exc}")
            return f"Error: {exc}"

        raw = result.get("raw_answer") or ""
        clean = result.get("answer") or ""
        answer = raw.strip() if raw.strip() else clean.strip()
        if not answer:
            status = str(result.get("status") or "incomplete")
            answer = f"The autonomous agent returned no final answer (status: {status})."

        answer = _strip_thinking(answer)

        self.tui.print_assistant_header(profile.get("label") or "Smara")
        self.tui.stream_markdown_chunk(answer + "\n")
        self.tui.print_stats(time.time() - started_at, len(result.get("tools_used") or []))

        self.history.append({"role": "user", "content": user_prompt})
        self.history.append({"role": "assistant", "content": answer})

        try:
            from .local_conversation_memory import SQLiteConversationMemory
            SQLiteConversationMemory.for_state(_desktop_state_path()).append_exchange(
                conversation_id="cli-local",
                workspace_id=str(self.workspace),
                user_message=user_prompt,
                assistant_message=answer,
            )
        except Exception:
            pass

        return answer

    def run_turn(self, user_prompt: str) -> str:
        """Run a full autonomous turn with tool calling and final response streaming."""
        # Skill learning is a local control command, not a model request.
        from .local_learning import handle_learn_command, is_learn_command
        if is_learn_command(user_prompt):
            result = handle_learn_command(
                user_prompt,
                workspace_root=self.workspace,
                state_path=_desktop_state_path(),
                conversation_id="cli-local",
            )
            answer = str(result.get("answer") or "").strip()
            from .local_conversation_memory import SQLiteConversationMemory
            SQLiteConversationMemory.for_state(_desktop_state_path()).append_exchange(
                conversation_id="cli-local",
                workspace_id=str(self.workspace),
                user_message=user_prompt,
                assistant_message=answer,
            )
            self.tui.print_assistant_header("Smara")
            self.tui.stream_markdown_chunk(answer)
            self.history.append({"role": "user", "content": user_prompt})
            self.history.append({"role": "assistant", "content": answer})
            return answer

        profile = self.active_profile
        api_key = _resolve_profile_key(profile, self.credentials)
        if api_key:
            return self._run_shared_local_turn(user_prompt, profile, api_key)

        self.tui.print_error(
            f"No API key configured for active model profile '{profile.get('label', self.active_id)}'.\n"
            f"Set the environment variable or credential (e.g. SMARA_MODEL_{profile.get('id', '').upper()}_API_KEY or SARVAM_API_KEY / GROK_API_KEY).\n"
            f"Run 'smara models' to view available profiles or 'smara /model <name>' to switch."
        )
        return "No model API key configured."


# ============================================================================
# Legacy Cloud Client & CLI Argument Parser
# ============================================================================

def _interactive_repl(engine: LocalAutonomousEngine, canonical_runner=None) -> None:
    """Claude Code inspired interactive terminal REPL."""
    tui = engine.tui
    approval_mode = "auto"
    
    try:
        from .prompt_editor import SmaraPromptSession
        prompt_session = SmaraPromptSession(engine.workspace)
    except Exception:
        prompt_session = None

    def execute(prompt: str) -> None:
        if canonical_runner is None:
            engine.run_turn(prompt)
            return
        agent_result, payload = canonical_runner(prompt)
        print(str(payload.get("answer") or agent_result.get("answer") or ""))

    tui.print_banner(
        model_label=engine.active_profile.get("label", engine.active_id),
        workspace_path=str(engine.workspace),
        zero_friction=(approval_mode == "auto"),
    )

    while True:
        try:
            if prompt_session:
                line = prompt_session.prompt("you")
            else:
                tui.print_prompt()
                line = input().strip()
        except (EOFError, KeyboardInterrupt):
            print("\nExiting Smara.")
            return

        if not line:
            continue

        if line in {"/exit", "/quit", "exit", "quit"}:
            print("Goodbye!")
            return

        if line == "/help":
            tui.print_help()
            continue

        if line == "/clear":
            os.system("cls" if os.name == "nt" else "clear")
            engine.history.clear()
            tui.print_banner(
                model_label=engine.active_profile.get("label", engine.active_id),
                workspace_path=str(engine.workspace),
                zero_friction=(approval_mode == "auto"),
            )
            continue

        if line in {"/trust", "/untrust"}:
            from .workspace_rules import is_workspace_trusted, trust_workspace, untrust_workspace
            if line == "/trust":
                trust_workspace(engine.workspace)
                print(tui.paint(f"\nTrusted workspace: {engine.workspace}", "GREEN"))
            else:
                untrust_workspace(engine.workspace)
                print(tui.paint(f"\nUntrusted workspace: {engine.workspace}", "YELLOW"))
            continue

        if line.startswith("/rules"):
            from .workspace_rules import discover_workspace_rules
            rules = discover_workspace_rules(engine.workspace)
            if rules.get("found"):
                print(tui.paint(f"\nDiscovered rules from {rules['filename']}:", "BOLD"))
                print(rules["content"])
            else:
                print(tui.paint("\nNo project rule file found (.smararules, SMARA.md, CLAUDE.md).", "YELLOW"))
            continue

        if line.startswith("/mcp"):
            from .mcp_client import MCPManager
            from .workspace_rules import is_workspace_trusted
            mgr = MCPManager(engine.workspace, trusted=is_workspace_trusted(engine.workspace))
            servers = mgr.discover_and_load()
            if servers:
                print(tui.paint(f"\nConnected MCP Servers ({len(servers)}):", "BOLD"))
                for s_name, s_proc in servers.items():
                    print(f"  ● {tui.paint(s_name, 'CYAN')} ({len(s_proc.tools)} tools)")
                    for t in s_proc.tools:
                        print(f"      - {t.get('name')}: {t.get('description', '')[:60]}")
            else:
                print(tui.paint("\nNo MCP servers configured (create mcp.json or .mcp/servers.json).", "YELLOW"))
            continue

        if line.startswith("/diff"):
            try:
                diff_proc = subprocess.run(["git", "diff", "HEAD"], cwd=str(engine.workspace), capture_output=True, text=True, timeout=5)
                diff_out = diff_proc.stdout.strip()
                if diff_out:
                    tui.render_diff(diff_out, "Working Tree Diffs")
                else:
                    print(tui.paint("\nWorking tree is clean (no uncommitted diffs).", "GREEN"))
            except Exception as e:
                tui.print_error(f"Git diff error: {e}")
            continue

        if line.startswith("/tree"):
            parts = line.split(maxsplit=1)
            depth = int(parts[1]) if len(parts) > 1 and parts[1].isdigit() else 2
            tui.print_tree(engine.workspace, max_depth=depth)
            continue

        if line.startswith("/approval"):
            parts = line.split(maxsplit=1)
            if len(parts) > 1 and parts[1].lower() in ("auto", "interactive"):
                approval_mode = parts[1].lower()
                print(tui.paint(f"Permission mode set to: {approval_mode}", "GREEN"))
            else:
                print(f"Current permission mode: {tui.paint(approval_mode, 'BOLD')} (options: auto, interactive)")
            continue

        if line.startswith("/test"):
            parts = line.split(maxsplit=1)
            filt = parts[1].strip() if len(parts) > 1 else ""
            cmd = f"pytest -q {filt}".strip()
            execute(f"Run tests with `{cmd}` and summarize passing/failing tests.")
            continue

        if line.startswith("/model"):
            parts = line.split(maxsplit=1)
            if len(parts) > 1:
                target = parts[1].strip()
                if engine.set_active_model(target):
                    print(tui.paint(f"Switched model to {engine.active_profile.get('label')}", "GREEN"))
                else:
                    print(tui.paint(f"Unknown model: {target}. Available: grok, sarvam, ollama, openrouter", "YELLOW"))
            else:
                print(f"Active model: {tui.paint(engine.active_profile.get('label'), 'BOLD')}")
                for p in engine.profiles:
                    star = "●" if p["id"] == engine.active_id else "○"
                    print(f"  {star} {p['id'].ljust(12)} - {p['label']} ({p['model']})")
            continue

        if line.startswith("/graph"):
            parts = line.split(maxsplit=1)
            sym = parts[1].strip() if len(parts) > 1 else "LocalTaskStore"
            execute(f"Inspect the Code Property Graph for the symbol '{sym}' in our codebase and report its defined methods, callers, and blast radius.")
            continue

        if line.startswith("/search"):
            parts = line.split(maxsplit=1)
            query = parts[1].strip() if len(parts) > 1 else "AI agent architectures 2026"
            execute(f"Research and explain {query}. Cite sources.")
            continue

        if line.startswith("/pdf"):
            parts = line.split(maxsplit=1)
            title = parts[1].strip() if len(parts) > 1 else "Agent Performance Audit 2026"
            execute(f"Create an executive PDF report titled '{title}' saved to reports/audit_summary.pdf.")
            continue

        if line.startswith("/docx"):
            parts = line.split(maxsplit=1)
            title = parts[1].strip() if len(parts) > 1 else "Agent Performance Audit 2026"
            execute(f"Create an executive Word DOCX report titled '{title}' saved to reports/audit_summary.docx.")
            continue

        if line.startswith("/workspace"):
            parts = line.split(maxsplit=1)
            if len(parts) > 1:
                engine.workspace = Path(parts[1].strip()).resolve()
                if prompt_session:
                    prompt_session = SmaraPromptSession(engine.workspace)
                print(tui.paint(f"Workspace set to {engine.workspace}", "GREEN"))
            else:
                print(f"Active workspace: {engine.workspace}")
            continue

        # Normal prompt execution
        try:
            execute(line)
        except Exception as exc:
            tui.print_error(str(exc))


def _token_file() -> Path:
    override = os.getenv("SMARA_TOKEN_FILE")
    if override:
        return Path(override)
    return Path.home() / ".smara" / "token.json"


def _save_token(data: dict) -> None:
    p = _token_file()
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data), encoding="utf-8")


def _load_token() -> str:
    p = _token_file()
    if p.exists():
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
            return data.get("access_token") or data.get("token") or ""
        except Exception:
            return ""
    return ""


def _clear_token() -> None:
    p = _token_file()
    if p.exists():
        try:
            p.unlink()
        except Exception:
            pass


def _request(client: httpx.Client, method: str, path: str, **kwargs: Any) -> Any:
    response = client.request(method, path, **kwargs)
    if response.status_code >= 400:
        try:
            detail = response.json().get("detail", response.text)
        except ValueError:
            detail = response.text
        raise RuntimeError(f"{response.status_code}: {detail}")
    return response.json() if response.content else {"ok": True}


def _client(args: argparse.Namespace) -> httpx.Client:
    headers: dict[str, str] = {"Accept": "application/json"}
    token = getattr(args, "token", "") or _load_token()
    if token:
        headers["Authorization"] = f"Bearer {token}"
    dev_account = getattr(args, "dev_account", "")
    if dev_account:
        headers["X-Smara-Account-Id"] = dev_account
    api = getattr(args, "api", "http://127.0.0.1:8080").rstrip("/")
    timeout_sec = float(getattr(args, "request_timeout", 30))
    timeout = httpx.Timeout(connect=10.0, read=timeout_sec, write=30.0, pool=10.0)
    return httpx.Client(base_url=api, headers=headers, timeout=timeout)


def build_parser() -> argparse.ArgumentParser:
    from .version import __version__
    parser = argparse.ArgumentParser(prog="smara", description="Smara Autonomous Developer CLI")
    parser.add_argument("--version", action="version", version=f"smara {__version__}")
    parser.add_argument("--api", default=os.getenv("SMARA_API_URL", "http://127.0.0.1:8080"))
    parser.add_argument("--token", default=os.getenv("SMARA_TOKEN", ""), help="Smara bearer token")
    parser.add_argument("--dev-account", default=os.getenv("SMARA_DEV_ACCOUNT", ""), help="development only")
    parser.add_argument("--request-timeout", default="30", help="HTTP read timeout in seconds")
    parser.add_argument("--workspace", "-w", default="default", help="Workspace root path")
    parser.add_argument("--model", "-m", help="Select model profile (grok, sarvam, ollama, openrouter)")
    parser.add_argument("--plain", action="store_true", help="Disable ANSI color styling")
    parser.add_argument("--hosted", action="store_true", help="Use legacy hosted cloud client")

    subparsers = parser.add_subparsers(dest="command", help="Quick subcommands")

    # Hosted CLI compatibility subcommands
    ask = subparsers.add_parser("ask", help="short direct conversation")
    ask.add_argument("message")
    ask.add_argument("--workspace", default="default")

    run = subparsers.add_parser("run", help="create a durable task or autonomous goal loop")
    run.add_argument("objective", nargs="?", default="", help="Goal or task objective")
    run.add_argument("--goal", action="store_true", help="Execute as autonomous long-horizon goal loop")
    run.add_argument("--resume", help="Resume interrupted goal session ID")
    run.add_argument("--title", default="Smara task")
    run.add_argument("--workspace", default="default")
    run.add_argument("--no-approval", action="store_true")
    run.add_argument("--prompt-file", help="Read a headless session prompt from a file")
    run.add_argument("--json", action="store_true", help="Emit durable session result JSON")
    run.add_argument("--budget-profile", default="auto", help="Budget profile; auto selects the governed Quick or Deep Research budget")
    run.add_argument(
        "--tool-profile",
        choices=["full", "research", "research-web", "research_web", "live-web", "coding"],
        default="full",
        help="Tool authority profile; research-web/live-web selects the verified canonical live-web workflow",
    )
    run.add_argument("--research-mode", choices=["auto", "quick", "deep"], default="auto", help="Research lane; auto judges the objective and records its decision")
    resume_cmd = subparsers.add_parser("resume", help="Inspect a durable local session result")
    resume_cmd.add_argument("session_id")
    resume_cmd.add_argument("--json", action="store_true")
    cancel_cmd = subparsers.add_parser("cancel", help="Cancel a durable local session")
    cancel_cmd.add_argument("session_id")
    inspect_cmd = subparsers.add_parser("inspect", help="Inspect durable local session events")
    inspect_cmd.add_argument("session_id")
    inspect_cmd.add_argument("--events", action="store_true")
    inspect_cmd.add_argument("--json", action="store_true")
    doctor_cmd = subparsers.add_parser("doctor", help="Check local harness prerequisites without revealing secrets")
    doctor_cmd.add_argument("--json", action="store_true")

    tasks = subparsers.add_parser("tasks", help="list durable tasks")
    tasks_sub = tasks.add_subparsers(dest="tasks_command")
    tasks_sub.add_parser("list")

    desktop_cmd = subparsers.add_parser("desktop", help="pair or revoke desktop executor")
    desktop_sub = desktop_cmd.add_subparsers(dest="desktop_command")
    pair_cmd = desktop_sub.add_parser("pair")
    pair_cmd.add_argument("--capability", default="local_file_read")
    revoke_cmd = desktop_sub.add_parser("revoke")
    revoke_cmd.add_argument("desktop_id")

    login_cmd = subparsers.add_parser("login", help="authenticate with Smara account")
    login_cmd.add_argument("code", nargs="?", default=None, help="pairing code")

    subparsers.add_parser("logout", help="logout and remove token")
    subparsers.add_parser("tools", help="list tools")
    plugins_cmd = subparsers.add_parser("plugins", help="manage declarative plugins")
    plugins_sub = plugins_cmd.add_subparsers(dest="plugin_action")
    plugins_sub.add_parser("list")
    plugin_enable = plugins_sub.add_parser("enable"); plugin_enable.add_argument("name")
    plugin_disable = plugins_sub.add_parser("disable"); plugin_disable.add_argument("name")
    plugin_remove = plugins_sub.add_parser("remove"); plugin_remove.add_argument("name")
    plugin_install = plugins_sub.add_parser("install", help="install a declarative local plugin manifest")
    plugin_install.add_argument("manifest")
    plugin_update = plugins_sub.add_parser("update", help="validate and atomically update a local plugin")
    plugin_update.add_argument("name"); plugin_update.add_argument("manifest")
    plugin_rollback = plugins_sub.add_parser("rollback", help="restore a retained plugin manifest version")
    plugin_rollback.add_argument("name"); plugin_rollback.add_argument("version")
    plugin_health = plugins_sub.add_parser("health", help="run non-mutating connector/MCP health probes")
    plugin_health.add_argument("name", nargs="?")
    subparsers.add_parser("approvals", help="list tasks awaiting approval")

    devices_cmd = subparsers.add_parser("devices", help="list or revoke authorized CLI devices")
    devices_sub = devices_cmd.add_subparsers(dest="device_command")
    devices_sub.add_parser("list")
    dev_revoke = devices_sub.add_parser("revoke")
    dev_revoke.add_argument("device_id")

    # Local Autonomous Subcommands
    p_memory = subparsers.add_parser("memory", help="Dual-Plane Memory Bridge (Local SQLite + Continuum/Syntarus)")
    p_memory.add_argument("memory_action", nargs="?", default="status", choices=["status", "sync", "search", "adr", "history", "conventions"], help="Memory action")
    p_memory.add_argument("query", nargs="*", default=[], help="Search query or sub-action for memory recall")
    p_memory.add_argument("--limit", type=int, default=5, help="Result limit")

    p_graph = subparsers.add_parser("graph", help="Inspect AST Code Graph & blast radius")
    p_graph.add_argument("symbol", nargs="?", default="LocalTaskStore", help="Symbol name")

    p_search = subparsers.add_parser("search", help="Live web research (Tavily/Exa)")
    p_search.add_argument("query", nargs="+", help="Search query")

    p_report = subparsers.add_parser("report", help="Compile executive PDF/DOCX report")
    p_report.add_argument("title", nargs="*", default=["Agent Audit"], help="Report title")
    p_report.add_argument("--format", choices=["pdf", "docx"], default="pdf", help="Document format")

    p_test = subparsers.add_parser("test", help="Run pytest test suite with optional auto-fix")
    p_test.add_argument("filter", nargs="*", default=[], help="Optional test file or filter expression")
    p_test.add_argument("--fix", action="store_true", help="Automatically diagnose and fix failing tests")

    p_refactor = subparsers.add_parser("refactor", help="Autonomous multi-file refactoring with rollback ledger")
    p_refactor.add_argument("instructions", nargs="+", help="Refactoring instructions")

    p_git = subparsers.add_parser("git", help="Smart Git Workspace and autonomous branching")
    p_git.add_argument("git_action", nargs="?", default="status", choices=["status", "branch", "commit", "log", "conflicts"], help="Git operation")
    p_git.add_argument("target", nargs="?", default=None, help="Target branch name or commit message")
    p_git.add_argument("-m", "--message", help="Commit message")
    p_git.add_argument("--ai", action="store_true", help="Auto-generate AI conventional commit message")

    p_find = subparsers.add_parser("find", help="Local Vector Semantic Code Search (Hybrid Lexical + Dense Embedding)")
    p_find.add_argument("query", nargs="+", help="Natural language query or symbol search")
    p_find.add_argument("--limit", type=int, default=5, help="Maximum number of results to display")

    p_index = subparsers.add_parser("index", help="Rebuild or refresh local SQLite semantic code index")
    p_index.add_argument("--force", action="store_true", help="Force re-indexing all files")

    p_browse = subparsers.add_parser("browse", help="Headless Browser Live Scraping & Screenshot Capture")
    p_browse.add_argument("url", help="Target URL or local HTML file path")
    p_browse.add_argument("--screenshot", action="store_true", help="Capture high-res PNG screenshot")

    p_e2e = subparsers.add_parser("e2e", help="Automated Browser E2E UI testing and component verification")
    p_e2e.add_argument("suite", nargs="?", default=None, help="Path to E2E test suite JSON file")

    p_swarm = subparsers.add_parser("swarm", help="Autonomous Multi-Agent Swarm (Architect + Implementer + Verifier + Auditor)")
    p_swarm.add_argument("objective", nargs="+", help="High-level engineering task objective")

    p_tool = subparsers.add_parser("tool", help="Invoke one safe read-only tool or custom capability")
    p_tool.add_argument("name", nargs="?", default="calculate", help="Tool name to invoke")
    p_tool.add_argument("--arguments", default="{}", help="JSON object of tool arguments")
    p_tool.add_argument("--workspace", default="default", help="Workspace ID")

    p_dyn = subparsers.add_parser("dynamic-tool", help="Dynamic Tool Synthesizer & Self-Expanding Tool Library")
    tool_subs = p_dyn.add_subparsers(dest="tool_subcommand")
    tool_subs.add_parser("list", help="List all synthesized dynamic tools")
    p_tcreate = tool_subs.add_parser("create", help="Synthesize, verify, and register a new custom tool")
    p_tcreate.add_argument("name", help="Tool identifier name")
    p_tcreate.add_argument("--code", required=True, help="Python code defining 'def run(payload: dict):'")
    p_tcreate.add_argument("--desc", default="", help="Tool description")
    p_trun = tool_subs.add_parser("run", help="Execute a synthesized dynamic tool")
    p_trun.add_argument("name", help="Tool name to execute")
    p_trun.add_argument("payload", nargs="?", default="{}", help="JSON payload string")

    p_research = subparsers.add_parser("research", help="Deep Autonomous Market Research & Intelligence Engine")
    p_research.add_argument("topic", nargs="+", help="Research topic or market to analyze")

    p_goal = subparsers.add_parser("goal", help="Manage long-horizon goal sessions")
    p_goal.add_argument("goal_action", nargs="?", default="list", choices=["list", "status", "resume"])
    p_goal.add_argument("goal_id", nargs="?", default=None)

    p_bench = subparsers.add_parser("benchmark", help="Run reproducible agent benchmark gates")
    p_bench.add_argument("--suite", choices=["gaia", "swe-bench", "desktop", "osworld"], default="gaia", help="Benchmark suite or readiness gate to run")
    p_bench.add_argument("--level", choices=["1", "2", "3"], default="1", help="GAIA Level (default: 1)")
    p_bench.add_argument("--count", type=int, default=None, help="Max tasks to evaluate (default: all)")
    p_bench.add_argument("--dataset", default=None, help="Existing local GAIA metadata.parquet/JSON/JSONL/CSV or snapshot directory")
    p_bench.add_argument("--readiness", action="store_true", help="Inspect local GAIA/OSWorld prerequisites without running tasks")
    p_bench.add_argument("--report", action="store_true", help="Automatically open generated PDF scorecard")

    subparsers.add_parser("models", help="List and configure model profiles")
    subparsers.add_parser("chat", help="Launch interactive Claude Code TUI")

    p_ocr = subparsers.add_parser("ocr", help="Digitize and extract text/markdown from documents or images using Sarvam OCR")
    p_ocr.add_argument("file", help="Path to PDF document or image file (.pdf, .png, .jpg, .webp)")
    p_ocr.add_argument("--lang", default="en-IN", help="Language code (default: en-IN)")
    p_ocr.add_argument("--format", default="md", choices=["md", "txt"], help="Output format (default: md)")
    p_ocr.add_argument("--output", "-o", default=None, help="Save extracted text to a file path")

    p_skills = subparsers.add_parser("skills", help="discover and promote learned declarative skills")
    skills_sub = p_skills.add_subparsers(dest="skills_action")
    skills_sub.add_parser("list")
    skill_view = skills_sub.add_parser("view"); skill_view.add_argument("name")
    skill_promote = skills_sub.add_parser("promote"); skill_promote.add_argument("name")
    skill_revoke = skills_sub.add_parser("revoke"); skill_revoke.add_argument("name")
    skill_validate = skills_sub.add_parser("validate", help="validate a versioned playbook without running it")
    skill_validate.add_argument("name"); skill_validate.add_argument("--version")
    skill_rollback = skills_sub.add_parser("rollback", help="restore a previously promoted skill version")
    skill_rollback.add_argument("name"); skill_rollback.add_argument("version")
    skill_reuse = skills_sub.add_parser("reuse-check", help="show whether automatic reuse is safe")
    skill_reuse.add_argument("name"); skill_reuse.add_argument("query"); skill_reuse.add_argument("--version")

    subparsers.add_parser("backends", help="probe Docker and WSL execution backends")
    gateway_cmd = subparsers.add_parser("gateway", help="inspect or process the local message gateway")
    gateway_sub = gateway_cmd.add_subparsers(dest="gateway_action")
    gateway_sub.add_parser("status")
    gateway_receive = gateway_sub.add_parser("receive"); gateway_receive.add_argument("channel"); gateway_receive.add_argument("sender"); gateway_receive.add_argument("text", nargs="+")
    gateway_sub.add_parser("retry")
    gateway_serve = gateway_sub.add_parser("serve"); gateway_serve.add_argument("--host", default="127.0.0.1"); gateway_serve.add_argument("--port", type=int, default=8787); gateway_serve.add_argument("--token", default=os.getenv("SMARA_GATEWAY_TOKEN", ""))
    schedule_cmd = subparsers.add_parser("schedule", help="manage local durable schedules")
    schedule_sub = schedule_cmd.add_subparsers(dest="schedule_action")
    schedule_sub.add_parser("list")
    schedule_sub.add_parser("run")
    schedule_add = schedule_sub.add_parser("add"); schedule_add.add_argument("name"); schedule_add.add_argument("interval", type=int); schedule_add.add_argument("payload", nargs="?", default="{}")
    schedule_pause = schedule_sub.add_parser("pause"); schedule_pause.add_argument("id")
    schedule_resume = schedule_sub.add_parser("resume"); schedule_resume.add_argument("id")
    schedule_remove = schedule_sub.add_parser("remove"); schedule_remove.add_argument("id")

    return parser


def main(argv: list[str] | None = None) -> int:
    for stream in (sys.stdin, sys.stdout, sys.stderr):
        if hasattr(stream, "reconfigure"):
            try:
                stream.reconfigure(encoding="utf-8", errors="replace")
            except Exception:
                pass
    raw_args = list(argv if argv is not None else sys.argv[1:])

    subcommands = {
        "graph", "search", "report", "test", "refactor", "git", "find",
        "index", "browse", "e2e", "memory", "swarm", "models", "chat", "login",
        "logout", "run", "research", "tasks", "tools", "plugins", "approvals",
        "devices", "desktop", "tool", "dynamic-tool", "ask", "goal", "benchmark", "resume", "cancel", "inspect", "doctor", "ocr", "skills", "backends", "gateway", "schedule"
    }

    # Extract top-level flags before checking for direct prompt
    model_override = None
    workspace_override = None
    plain_override = False
    cleaned_args = []
    i = 0
    while i < len(raw_args):
        arg = raw_args[i]
        if arg in ("-m", "--model") and i + 1 < len(raw_args):
            model_override = raw_args[i + 1]
            i += 2
        elif arg.startswith("--model="):
            model_override = arg.split("=", 1)[1]
            i += 1
        elif arg in ("-w", "--workspace") and i + 1 < len(raw_args):
            workspace_override = raw_args[i + 1]
            i += 2
        elif arg.startswith("--workspace="):
            workspace_override = arg.split("=", 1)[1]
            i += 1
        elif arg == "--plain":
            plain_override = True
            i += 1
        else:
            cleaned_args.append(arg)
            i += 1

    parser = build_parser()
    direct_prompt = None

    if cleaned_args and cleaned_args[0] not in subcommands and not cleaned_args[0].startswith("-"):
        direct_prompt = " ".join(cleaned_args)
        parsed_args = parser.parse_args([])
    else:
        parsed_args = parser.parse_args(raw_args)

    if model_override:
        parsed_args.model = model_override
    if workspace_override:
        parsed_args.workspace = workspace_override
    if plain_override:
        parsed_args.plain = True

    tui = TerminalRenderer(plain=parsed_args.plain)
    ws_arg = getattr(parsed_args, "workspace", None)
    workspace = Path(ws_arg).resolve() if (ws_arg and ws_arg != "default") else Path.cwd()
    engine = LocalAutonomousEngine(workspace_root=workspace, tui=tui)

    if parsed_args.model:
        engine.set_active_model(parsed_args.model)

    def run_canonical(prompt: str, session=None, budget=None):
        """Run every autonomous CLI surface through the durable engine."""
        from .autonomous_agent import SmaraAutonomousAgent,normalize_tool_profile
        from .harness import BUDGET_PROFILES, Budget, SessionEngine
        from .runtime_session import session_store_for_workspace
        from .research_modes import select_research_lane,should_route_to_research
        active_workspace=engine.workspace
        requested_mode=getattr(parsed_args,"research_mode","auto")
        requested_profile=normalize_tool_profile(getattr(parsed_args,"tool_profile","full"))
        if requested_profile=="full" and (requested_mode!="auto" or should_route_to_research(prompt)):
            requested_profile="research_web"
        if session is None and budget is None and requested_profile=="research_web":
            selected=select_research_lane(prompt,requested_mode)[0].mode
            budget=BUDGET_PROFILES["research_deep" if selected=="deep" else "research_quick"]
        ephemeral_session = session is None and budget is None
        session=session or SessionEngine(active_workspace,budget=budget or Budget())
        runtime_store=session_store_for_workspace(active_workspace)
        runtime_store.create_or_get(
            session.session_id,
            request=prompt,
            workspace_id=str(active_workspace),
            account_id="local",
            mode="cli",
            tool_profile=requested_profile,
            research_mode=requested_mode,
        )
        if runtime_store.should_cancel(session.session_id):
            session.cancel()
        else:
            runtime_store.checkpoint(
                session.session_id,
                status="running",
                tool_profile=requested_profile,
                research_mode=requested_mode,
                event="turn.resumed" if session.get("request") else "turn.started",
                event_payload={"request": prompt[:500]},
            )
        model_config=session.get("model_config")
        if model_config is None:
            profile=engine.active_profile
            model_config={"profile_id":profile.get("id","default"),"base_url":profile.get("base_url","https://api.sarvam.ai/v2"),"model":profile.get("model","sarvam-105b"),"auth_header":profile.get("auth_header","authorization")}
            session.set("model_config",model_config)
        profile=next((item for item in engine.profiles if item.get("id")==model_config.get("profile_id")),model_config)
        tool_profile=normalize_tool_profile(session.get("tool_profile") or requested_profile)
        session.set("tool_profile",tool_profile)
        research_mode=session.get("research_mode") or requested_mode
        api_key=_resolve_profile_key(profile,engine.credentials)
        # Direct/ask prompts must fail fast when no provider is configured.
        # Durable `run`/resume calls keep their session path intact so a
        # caller can configure a provider and resume without losing state.
        if not api_key and ephemeral_session:
            answer=f"No API key configured for active model profile '{profile.get('label', profile.get('id', 'default'))}'. Configure a local provider in Settings or run 'smara models'."
            canonical=session.finish_incremental("needs_input",answer,("model provider credential is missing",))
            runtime_store.checkpoint(session.session_id,status="needs_input",result=canonical,unresolved=canonical.get("unresolved_items") or [],event="turn.needs_input",event_payload={"reason":"missing_provider_credential"})
            from .app_adapter import application_envelope
            payload={**canonical,**application_envelope(session,canonical,runtime_store=runtime_store)}
            return canonical,payload
        agent=SmaraAutonomousAgent(api_key=api_key,base_url=model_config["base_url"],model=model_config["model"],auth_header=model_config.get("auth_header","authorization"),workspace_root=active_workspace,profile=tool_profile,session_engine=session,research_mode=research_mode)
        try:
            agent_result=agent.run(prompt,max_iterations=None)
        except Exception as exc:
            status="cancelled" if runtime_store.should_cancel(session.session_id) or session.get("cancelled",False) else "failed"
            runtime_store.checkpoint(session.session_id,status=status,unresolved=[str(exc)[:500]],event=f"turn.{status}",event_payload={"error":str(exc)[:500]})
            raise
        payload=agent_result.get("session") or session.inspect().get("state",{}).get("result") or session.inspect()
        from .app_adapter import application_envelope
        runtime_status="cancelled" if runtime_store.should_cancel(session.session_id) else str(payload.get("status") or "needs_input")
        runtime_store.checkpoint(session.session_id,status=runtime_status,result=payload,unresolved=payload.get("unresolved_items") or [],event=f"turn.{runtime_status}")
        payload={**payload,**application_envelope(session,payload,runtime_store=runtime_store)}
        return agent_result,payload

    if direct_prompt:
        agent_result,payload=run_canonical(direct_prompt)
        print(str(payload.get("answer") or agent_result.get("answer") or ""))
        return 0 if payload.get("status")=="completed" else 1

    cmd = getattr(parsed_args, "command", None) or getattr(parsed_args, "subcommand", None)

    if cmd == "doctor":
        from .doctor import diagnose
        payload=diagnose(workspace)
        print(json.dumps(payload, indent=2)); return 0 if payload["ok"] else 1

    if cmd in {"resume", "cancel", "inspect"}:
        from .harness import SessionEngine
        session = SessionEngine(workspace, parsed_args.session_id)
        if cmd == "cancel":
            from .runtime_session import session_store_for_workspace
            runtime_store=session_store_for_workspace(workspace)
            if runtime_store.get(parsed_args.session_id) is None:
                state = session.inspect().get("state", {})
                runtime_store.create_or_get(parsed_args.session_id, request=str(state.get("request") or ""), workspace_id=str(workspace), mode="cli")
            runtime_store.request_cancel(parsed_args.session_id)
            session.cancel(); payload = session.inspect()
        elif cmd == "resume":
            record = session.inspect(); prompt = str(record["state"].get("request") or "")
            _,payload=run_canonical(prompt,session=session)
        else:
            payload = session.inspect()
            from .runtime_session import session_store_for_workspace
            runtime_store=session_store_for_workspace(workspace)
            if runtime_store.get(parsed_args.session_id) is None:
                state = payload.get("state", {})
                runtime_store.create_or_get(parsed_args.session_id, request=str(state.get("request") or ""), workspace_id=str(workspace), mode="cli")
            with_runtime=runtime_store.snapshot(parsed_args.session_id)
            payload["runtime"] = with_runtime
            payload["event_cursor"] = with_runtime["cursor"]
        compact = payload.get("state", payload) if cmd != "resume" else payload
        print(json.dumps(payload if getattr(parsed_args, "events", False) or getattr(parsed_args, "json", False) else compact, indent=2))
        return 0 if cmd != "resume" or payload.get("status") == "completed" else 1

    if cmd == "run" and not getattr(parsed_args, "goal", False):
        from .harness import BUDGET_PROFILES, SessionEngine
        prompt = Path(parsed_args.prompt_file).read_text(encoding="utf-8") if parsed_args.prompt_file else parsed_args.objective
        if not prompt.strip():
            print(json.dumps({"status": "needs_input", "answer": "", "unresolved_items": ["prompt is empty"]}, indent=2)); return 1
        budget_profile = parsed_args.budget_profile
        if budget_profile == "auto":
            from .autonomous_agent import normalize_tool_profile
            from .research_modes import select_research_lane,should_route_to_research
            effective_profile=normalize_tool_profile(parsed_args.tool_profile)
            if effective_profile=="full" and (parsed_args.research_mode!="auto" or should_route_to_research(prompt)):
                effective_profile="research_web"
                parsed_args.tool_profile="research_web"
            if effective_profile == "research_web":
                budget_profile = "research_deep" if select_research_lane(prompt, parsed_args.research_mode)[0].mode == "deep" else "research_quick"
            else:
                budget_profile = "short"
        if budget_profile not in BUDGET_PROFILES:
            print(json.dumps({"status": "denied", "answer": "", "unresolved_items": [f"unknown budget profile: {parsed_args.budget_profile}"]}, indent=2)); return 1
        session = SessionEngine(workspace, budget=BUDGET_PROFILES[budget_profile])
        _,payload=run_canonical(prompt,session=session)
        if parsed_args.json:
            print(json.dumps(payload, indent=2))
        else:
            print(str(payload.get("answer") or ""))
            if payload.get("research_mode"):
                print(f"Research mode: {payload['research_mode']}")
            if payload.get("unresolved_work"):
                print("Unresolved: " + "; ".join(str(item) for item in payload["unresolved_work"]))
            print(f"Session: {payload['session_id']} (resume with: {payload['resume']['command']})")
        return 0 if payload["status"] == "completed" else 1

    # Handle subcommands
    if cmd == "ask":
        msg = getattr(parsed_args, "message", "")
        if msg:
            agent_result,payload=run_canonical(msg)
            print(str(payload.get("answer") or agent_result.get("answer") or ""))
            return 0 if payload.get("status")=="completed" else 1
        print(tui.paint("Error: Message cannot be empty for 'ask'.", "RED"))
        return 1

    if cmd == "git":
        from .git_agent import GitWorkspaceManager
        mgr = GitWorkspaceManager(engine.workspace)
        action = parsed_args.git_action

        if not mgr.is_git_repo():
            print(tui.paint(f"Error: {engine.workspace} is not a git repository.", "RED"))
            return 1

        if action == "status":
            st = mgr.get_status()
            print(tui.paint(f"\n🌿 Git Workspace Status (Branch: {st.branch})", "BOLD"))
            if st.is_clean:
                print(tui.paint("✓ Working tree is clean. Zero uncommitted changes.\n", "GREEN"))
            else:
                print(f"Total Changes: {tui.paint(str(st.total_changes), 'YELLOW')}")
                if st.staged_files:
                    print(tui.paint("Staged files:", "GREEN"))
                    for f in st.staged_files: print(f"  + {f}")
                if st.unstaged_files:
                    print(tui.paint("Unstaged modifications:", "YELLOW"))
                    for f in st.unstaged_files: print(f"  • {f}")
                if st.untracked_files:
                    print(tui.paint("Untracked files:", "CYAN"))
                    for f in st.untracked_files: print(f"  ? {f}")
                if st.conflicts:
                    print(tui.paint("Merge Conflicts:", "RED"))
                    for f in st.conflicts: print(f"  ✗ {f}")
                print()
            return 0

        if action == "branch":
            target = parsed_args.target
            if not target:
                branches = mgr.list_branches()
                st = mgr.get_status()
                print(tui.paint("\nLocal Git Branches:", "BOLD"))
                for b in branches:
                    star = "●" if b == st.branch else "○"
                    print(f"  {star} {b}")
                print()
                return 0
            # Switch or create
            branches = mgr.list_branches()
            if target in branches:
                ok, msg = mgr.switch_branch(target)
            else:
                ok, msg = mgr.create_branch(target)
            color = "GREEN" if ok else "RED"
            print(tui.paint(f"\n{msg}\n", color))
            return 0 if ok else 1

        if action == "commit":
            msg = parsed_args.message or parsed_args.target
            if parsed_args.ai or not msg:
                ai_data = mgr.generate_smart_commit_message()
                msg = ai_data["title"]
                print(tui.paint(f"\n⚡ Auto-Generated Conventional Commit:", "CYAN"))
                print(f"Title: {tui.paint(msg, 'BOLD')}")
                if ai_data.get("description"):
                    print(f"Details:\n{ai_data['description']}")
            
            ok, res_msg = mgr.commit(msg)
            if ok:
                print(tui.paint(f"\n✓ Committed: {msg}\n", "GREEN"))
                return 0
            else:
                print(tui.paint(f"\n✗ Commit failed: {res_msg}\n", "RED"))
                return 1

        if action == "log":
            commits = mgr.get_recent_commits(limit=10)
            print(tui.paint(f"\nRecent Commits ({len(commits)}):", "BOLD"))
            for c in commits:
                print(f"  {tui.paint(c['short_hash'], 'YELLOW')} {tui.paint(c['message'], 'BOLD')} ({tui.paint(c['author'], 'CYAN')}, {c['date']})")
            print()
            return 0

        if action == "conflicts":
            conflicts = mgr.detect_conflicts()
            if not conflicts:
                print(tui.paint("\n✓ Zero merge conflicts detected in workspace.\n", "GREEN"))
            else:
                print(tui.paint(f"\n⚠️ {len(conflicts)} files with merge conflict markers found:", "RED"))
                for c in conflicts:
                    print(f"  ✗ {c['file']}")
                print()
            return 0

    if cmd == "index":
        from .semantic_search import SemanticCodeSearcher
        searcher = SemanticCodeSearcher(engine.workspace)
        tui.print_tool_start("local_graph", "Indexing workspace into local SQLite semantic database...")
        stats = searcher.index_workspace(force=parsed_args.force)
        tui.print_tool_result("local_graph", True, f"Indexed {stats['indexed_files']} files, skipped {stats['skipped_files']}, added {stats['total_chunks_added']} chunks")
        print(tui.paint(f"\n✓ Semantic index updated: {stats['total_chunks_added']} code symbols indexed.\n", "GREEN"))
        return 0

    if cmd == "find":
        from .semantic_search import SemanticCodeSearcher
        query = " ".join(parsed_args.query)
        searcher = SemanticCodeSearcher(engine.workspace)
        tui.print_tool_start("local_graph", f"Searching for '{query}' (Hybrid Lexical + Dense Vector)...")
        results = searcher.search(query, limit=parsed_args.limit)
        tui.print_tool_result("local_graph", True, f"Found {len(results)} relevant code units")

        if not results:
            print(tui.paint(f"\nNo code chunks found matching '{query}'.\n", "YELLOW"))
            return 0

        print(tui.paint(f"\n🔍 Top Results for \"{query}\":\n", "BOLD"))
        for i, r in enumerate(results, 1):
            badge = f"[{r.percentage}% match | {r.match_type.upper()}]"
            print(f"  {i}. {tui.paint(r.symbol_name, 'CYAN')} ({r.kind}) {tui.paint(badge, 'GREEN' if r.percentage >= 70 else 'YELLOW')}")
            print(f"     File: {tui.paint(f'{r.file_path}:{r.start_line}-{r.end_line}', 'BOLD')}")
            if r.docstring:
                first_doc = r.docstring.splitlines()[0][:90]
                print(f"     Doc:  {tui.paint(first_doc, 'DIM')}")
            snippet_lines = [l for l in r.code_snippet.splitlines() if l.strip()][:3]
            if snippet_lines:
                print("     Code:")
                for l in snippet_lines:
                    print(f"       │ {l[:80]}")
            print()
        return 0

    if cmd == "browse":
        from .browser_sidecar import BrowserSidecarEngine
        engine_sidecar = BrowserSidecarEngine(engine.workspace)
        url = parsed_args.url
        tui.print_tool_start("local_browser", f"Scraping '{url}' with native headless Chromium...")
        scrape_res = engine_sidecar.scrape_url(url)
        
        if scrape_res["success"]:
            tui.print_tool_result("local_browser", True, f"Loaded '{scrape_res['title']}' in {scrape_res['duration_ms']}ms")
            print(tui.paint(f"\n🌐 Page: {scrape_res['title']}", "BOLD"))
            print(f"URL: {tui.paint(url, 'CYAN')}")
            if scrape_res.get("headings"):
                print(tui.paint("Key Headings:", "BOLD"))
                for h in scrape_res["headings"]:
                    print(f"  • {h}")
            if scrape_res.get("content_snippet"):
                print(tui.paint("\nContent Preview:", "BOLD"))
                print(scrape_res["content_snippet"][:400] + "...\n")
        else:
            tui.print_tool_result("local_browser", False, f"Failed: {scrape_res.get('error', 'Error')}")

        if parsed_args.screenshot:
            tui.print_tool_start("local_browser", f"Capturing PNG screenshot...")
            shot = engine_sidecar.capture_screenshot(url)
            tui.print_tool_result("local_browser", shot["success"], f"Screenshot saved: {shot.get('file_path')}")
            print(tui.paint(f"✓ Screenshot captured: {shot.get('file_path')}\n", "GREEN"))
        return 0

    if cmd == "e2e":
        from .browser_sidecar import BrowserSidecarEngine
        engine_sidecar = BrowserSidecarEngine(engine.workspace)
        suite_path = parsed_args.suite
        
        if suite_path and Path(suite_path).exists():
            suite_data = json.loads(Path(suite_path).read_text(encoding="utf-8"))
            suite_name = suite_data.get("name", "Custom E2E Suite")
            steps = suite_data.get("steps", [])
        else:
            suite_name = "Smara Local Workspace Health E2E"
            steps = [
                {"action": "navigate", "target": "https://example.com"},
                {"action": "assert_title", "expected": "Example Domain"},
                {"action": "assert_text", "expected": "documentation examples"},
                {"action": "screenshot", "target": "https://example.com"},
            ]

        tui.print_tool_start("local_browser", f"Running E2E Suite: '{suite_name}' ({len(steps)} steps)...")
        res = engine_sidecar.run_e2e_flow(suite_name, steps)
        tui.print_tool_result("local_browser", res.success, f"{res.passed_count} passed, {res.failed_count} failed in {res.total_duration_ms}ms")

        print(tui.paint(f"\n🌐 E2E Replay Timeline ({suite_name}):", "BOLD"))
        for s in res.steps:
            icon = "✓" if s.status == "passed" else "✗"
            color = "GREEN" if s.status == "passed" else "RED"
            print(f"  {tui.paint(icon, color)} Step {s.step_index} [{s.action.upper()}] - {s.details} ({s.duration_ms}ms)")

        if res.success:
            print(tui.paint(f"\n✓ All {res.passed_count} E2E assertions passed cleanly!\n", "GREEN"))
            return 0
        else:
            print(tui.paint(f"\n✗ E2E Flow Failed: {res.failure_reason}\n", "RED"))
            return 1

    if cmd == "memory":
        from .dual_plane_memory import DualPlaneMemoryBridge
        bridge = DualPlaneMemoryBridge(engine.workspace)
        action = parsed_args.memory_action

        if action == "status":
            st = bridge.get_status()
            print(tui.paint("\n🧠 Smara Dual-Plane Memory Bridge Status:\n", "BOLD"))
            
            p1 = st.plane_1_local
            print(f"  {tui.paint('● Plane 1 (Local):', 'CYAN')} {p1.name}")
            print(f"    Status: {tui.paint(p1.status.upper(), 'GREEN' if p1.status == 'active' else 'YELLOW')} | Symbols: {p1.items_count}")
            print(f"    Path:   {tui.paint(p1.endpoint, 'DIM')}")
            print(f"    Info:   {p1.details}\n")

            p2 = st.plane_2_continuum
            p2_color = 'GREEN' if p2.status == 'connected' else 'YELLOW'
            print(f"  {tui.paint('● Plane 2 (Continuum/Syntarus):', 'PURPLE')} {p2.name}")
            print(f"    Status: {tui.paint(p2.status.upper(), p2_color)} | Synced: {p2.items_count}")
            print(f"    Server: {tui.paint(p2.endpoint, 'DIM')}")
            print(f"    Info:   {p2.details}\n")

            print(f"  Bridge Active: {tui.paint('YES', 'GREEN') if st.bridge_active else tui.paint('NO', 'RED')}")
            if st.last_sync_time:
                print(f"  Last Sync:     {st.last_sync_time}")
            print()
            return 0

        if action == "sync":
            tui.print_tool_start("local_integration", "Syncing local architectural decisions to Continuum Memory Plane...")
            sync_res = bridge.sync_to_continuum(force=True)
            tui.print_tool_result("local_integration", sync_res["success"], f"Synced {sync_res['synced_count']} / {sync_res.get('total_items', 0)} items")
            if sync_res["success"]:
                print(tui.paint(f"\n✓ Successfully synced {sync_res['synced_count']} architectural memories to Continuum at {sync_res['last_sync_time']}\n", "GREEN"))
                return 0
            else:
                print(tui.paint(f"\n✗ Sync failed: {sync_res.get('error', 'Error')}\n", "RED"))
                return 1

        if action == "search":
            query = " ".join(parsed_args.query)
            if not query:
                print(tui.paint("Please provide a search query. Example: smara memory search 'session tokens'", "YELLOW"))
                return 1
            tui.print_tool_start("local_integration", f"Dual-Plane Recall for: '{query}'...")
            res = bridge.recall(query, top_k=parsed_args.limit)
            tui.print_tool_result("local_integration", True, f"Retrieved in {res.retrieval_ms}ms")
            print(tui.paint(f"\n🧠 Dual-Plane Recall for \"{query}\" ({res.retrieval_ms}ms):\n", "BOLD"))
            if res.fused_context:
                print(res.fused_context)
            else:
                print(tui.paint("No matching memories or code symbols found.\n", "YELLOW"))
            return 0

        if action == "adr":
            sub = parsed_args.query[0].lower() if parsed_args.query else "list"
            if sub == "list" or not parsed_args.query:
                adrs = bridge.coding_engine.adr_manager.list_adrs()
                print(tui.paint(f"\n🏛️ Architecture Decision Records (ADRs) - {len(adrs)} active:\n", "BOLD"))
                for a in adrs:
                    status_color = "GREEN" if a.status == "Accepted" else "YELLOW"
                    print(f"  • {tui.paint(f'ADR-{a.id}', 'CYAN')} [{tui.paint(a.status, status_color)}] {tui.paint(a.title, 'BOLD')} ({a.date})")
                    if a.symbols_affected:
                        print(f"    Symbols: {tui.paint(', '.join(a.symbols_affected), 'DIM')}")
                    print(f"    Decision: {a.decision[:100]}...\n")
                return 0
            elif sub == "show":
                target_id = parsed_args.query[1] if len(parsed_args.query) > 1 else "0001"
                adr = bridge.coding_engine.adr_manager.get_adr(target_id)
                if not adr:
                    print(tui.paint(f"ADR-{target_id} not found.", "RED"))
                    return 1
                print(f"\n{adr.to_markdown()}\n")
                return 0
            elif sub == "create":
                title = " ".join(parsed_args.query[1:]) if len(parsed_args.query) > 1 else "New Architecture Decision"
                new_adr = bridge.coding_engine.adr_manager.create_adr(
                    title=title,
                    context="Recorded via Smara CLI.",
                    decision=f"Adopt {title} for enhanced maintainability.",
                    consequences="Improves codebase resilience and developer velocity.",
                )
                print(tui.paint(f"\n✓ Created ADR-{new_adr.id}: '{new_adr.title}'\n", "GREEN"))
                return 0

        if action == "history":
            sym = parsed_args.query[0] if parsed_args.query else "DualPlaneMemoryBridge"
            tui.print_tool_start("local_graph", f"Tracking AST diff history for symbol: '{sym}'...")
            bridge.coding_engine.diff_tracker.compute_diff_and_record()
            history = bridge.coding_engine.diff_tracker.get_symbol_history(sym)
            tui.print_tool_result("local_graph", True, f"Found {len(history)} evolutionary diffs")
            print(tui.paint(f"\n📜 Symbol Evolution Timeline for '{sym}':\n", "BOLD"))
            if not history:
                print(tui.paint(f"No evolutionary mutations recorded for '{sym}' yet.\n", "YELLOW"))
                return 0
            for h in history:
                color = "GREEN" if h.change_type == "added" else "YELLOW" if h.change_type == "signature_modified" else "CYAN"
                print(f"  • [{tui.paint(h.change_type.upper(), color)}] {h.diff_description}")
                print(f"    File: {tui.paint(h.file_path, 'DIM')} | Timestamp: {h.timestamp[:19]}\n")
            return 0

        if action == "conventions":
            tui.print_tool_start("local_graph", "Analyzing workspace ASTs for coding conventions...")
            convs = bridge.coding_engine.convention_learner.learn_conventions()
            tui.print_tool_result("local_graph", True, f"Analyzed {convs.analyzed_files_count} files")
            print(tui.paint(f"\n📐 Learned Codebase Conventions ({convs.workspace_name}):\n", "BOLD"))
            print(f"  • Type Hint Coverage: {tui.paint(str(convs.type_hint_coverage) + '%', 'GREEN')}")
            print(f"  • Async Workflow:     {tui.paint(str(convs.async_percentage) + '%', 'CYAN')}")
            print(f"  • Test Framework:     {tui.paint(convs.test_framework, 'BOLD')}")
            print(tui.paint("\nKey Inferred Rules & Patterns:", "BOLD"))
            for p in convs.key_patterns:
                print(f"  ✓ {p}")
            print()
            return 0

    if cmd == "swarm":
        from .swarm import SwarmOrchestrator
        objective = " ".join(parsed_args.objective)
        print(tui.paint(f"\n🐝 Starting Smara Multi-Agent Swarm: '{objective}'\n", "BOLD"))
        orchestrator = SwarmOrchestrator(engine.workspace)

        def on_event(name, role, detail):
            role_colors = {
                "architect": "PURPLE",
                "implementer": "CYAN",
                "verifier": "YELLOW",
                "auditor": "GREEN",
            }
            c = role_colors.get(role.value, "BOLD")
            icon = "🧠" if role.value == "architect" else "💻" if role.value == "implementer" else "🧪" if role.value == "verifier" else "🛡️"
            print(f"  {icon} [{tui.paint(role.value.upper(), c)}] {detail}")

        result = orchestrator.run_swarm(objective, on_event=on_event)
        
        status_color = "GREEN" if result.status == "SUCCESS" else "YELLOW"
        print(tui.paint(f"\n✓ Swarm Session {result.session_id} Complete [{result.status}] ({result.duration_ms}ms):\n", status_color))
        print(f"  • Scoped Symbols:  {', '.join(result.architect_plan.target_symbols) if result.architect_plan else 'None'}")
        print(f"  • Tests Verified:  {result.tests_passed}/{result.tests_run} passed")
        print(f"  • Security Audit:  {tui.paint('PASSED', 'GREEN') if result.audit_passed else tui.paint('FAILED', 'RED')}")
        if result.commit_message:
            print(f"  • Semantic Commit: {tui.paint(result.commit_message.splitlines()[0], 'DIM')}")
        print()
        return 0 if result.status in ("SUCCESS", "HEALED") else 1

    if cmd == "benchmark":
        suite = getattr(parsed_args, "suite", "gaia")
        level = getattr(parsed_args, "level", "1")
        count = getattr(parsed_args, "count", None)
        dataset = getattr(parsed_args, "dataset", None)
        readiness = getattr(parsed_args, "readiness", False)
        auto_open = getattr(parsed_args, "report", False)

        if suite == "gaia":
            if readiness:
                from benchmarks.gaia_readiness import GaiaReadiness
                summary = GaiaReadiness(workspace_root=engine.workspace, dataset_path=Path(dataset) if dataset else None).inspect()
                color = "GREEN" if summary["status"] == "ready_to_invoke_fair_runner" else "YELLOW"
                print(tui.paint(f"\nGAIA readiness: {summary['status']}\n", color))
                for item in summary["checks"]:
                    marker = "✓" if item["ok"] else "•"
                    print(f"  {marker} {item['name']}: {item['detail']}")
                print(f"\n  📄 Readiness report: {tui.paint(summary['report_path'], 'CYAN')}")
                return 0 if summary["status"] == "ready_to_invoke_fair_runner" else 2
            print(tui.paint(f"\n🏆 Launching strict GAIA shared-runtime evaluation (Level {level})...\n", "BOLD"))
            from benchmarks.gaia_fair_runner import GaiaFairBenchmark
            token = os.environ.get("HF_TOKEN", "")
            runner = GaiaFairBenchmark(token=token, workspace_root=engine.workspace, dataset_path=Path(dataset) if dataset else None)
            try:
                summary = runner.evaluate_level(level=level, max_tasks=count)
            except RuntimeError as exc:
                print(tui.paint(f"GAIA evaluation did not start: {exc}", "YELLOW"))
                return 2
            color = "GREEN" if summary["accuracy_percent"] >= 90.0 else "YELLOW"
            print(tui.paint(f"\n✓ GAIA Level {level}: {summary['correct']}/{summary['total_scored']} strict matches ({summary['accuracy_percent']}%). {summary['execution_errors']} execution errors.\n", color))
            print(f"  📄 Reproducible JSON report: {tui.paint(summary['report_path'], 'CYAN')}")
            return 0

        elif suite == "swe-bench":
            print(tui.paint("\n🔧 Launching SWE-bench Code Repair Benchmark...\n", "BOLD"))
            from benchmarks.swe_bench_runner import SweBenchRunner
            evaluator = SweBenchRunner(workspace_root=engine.workspace)
            summary = evaluator.run_all()
            rate = summary.get("resolution_rate_percent", summary.get("accuracy_percent", 100.0))
            resolved = summary.get("resolved", 0)
            total = summary.get("total_tasks", summary.get("total_instances", 4))
            color = "GREEN" if rate == 100.0 else "YELLOW"
            print(tui.paint(f"\n✓ SWE-bench Evaluation Complete: {resolved}/{total} ({rate}%) in {summary.get('total_duration_seconds', 0)}s\n", color))
            pdf_path = engine.workspace / "reports" / "swe_bench_results.pdf"
            if pdf_path.exists():
                print(f"  📄 Official Scorecard PDF: {tui.paint(str(pdf_path), 'CYAN')}")
                if auto_open:
                    import webbrowser
                    webbrowser.open(str(pdf_path))
            return 0

        elif suite == "desktop":
            print(tui.paint("\n🖥️ Launching GAIA-Style Desktop Multi-Step Tasks...\n", "BOLD"))
            from benchmarks.gaia_desktop_runner import GaiaDesktopBenchmark
            runner = GaiaDesktopBenchmark(
                workspace_root=engine.workspace,
                dataset_path=Path(dataset) if dataset else None,
            )
            summary = runner.run_all(level=level, max_tasks=count)
            rate = summary.get("pass_rate_percent", summary.get("accuracy_percent", 0.0))
            passed = summary.get("passed", summary.get("passed_tasks", 0))
            total = summary.get("total_tasks", 0)
            color = "GREEN" if rate == 100.0 else "YELLOW"
            print(tui.paint(f"\n✓ Desktop Tasks Complete: {passed}/{total} scored ({rate}%). {summary.get('execution_errors', 0)} execution errors.\n", color))
            report_path = summary.get("report_path")
            if report_path:
                print(f"  📄 Reproducible JSON report: {tui.paint(str(report_path), 'CYAN')}")
                if auto_open:
                    import webbrowser
                    webbrowser.open(str(report_path))
            return 0 if not summary.get("execution_errors") else 2

        elif suite == "osworld":
            from benchmarks.osworld_readiness import OSWorldReadinessRunner
            summary = OSWorldReadinessRunner(workspace_root=engine.workspace).preflight()
            color = "GREEN" if summary["status"] == "ready_to_invoke_external_environment" else "YELLOW"
            print(tui.paint(f"\nOSWorld readiness: {summary['status']}\n", color))
            for item in summary["checks"]:
                marker = "✓" if item["ok"] else "•"
                print(f"  {marker} {item['name']}: {item['detail']}")
            print(f"\n  📄 Readiness report: {tui.paint(summary['report_path'], 'CYAN')}")
            return 0 if summary["status"] == "ready_to_invoke_external_environment" else 2

    if cmd == "plugins":
        from .plugins import PluginManager
        manager = PluginManager(engine.workspace)
        action = getattr(parsed_args, "plugin_action", None) or "list"
        try:
            if action == "list": payload = manager.discover()
            elif action == "enable": payload = manager.set_enabled(parsed_args.name, True)
            elif action == "disable": payload = manager.set_enabled(parsed_args.name, False)
            elif action == "install": payload = manager.install(parsed_args.manifest)
            elif action == "update": payload = manager.update(parsed_args.name, parsed_args.manifest)
            elif action == "rollback": payload = manager.rollback(parsed_args.name, parsed_args.version)
            elif action == "health": payload = manager.health(parsed_args.name)
            else: manager.remove(parsed_args.name); payload = {"status": "removed", "name": parsed_args.name}
            print(json.dumps(payload, indent=2)); return 0
        except (KeyError, ValueError) as exc:
            print(json.dumps({"status": "error", "error": str(exc)}, indent=2)); return 1

    if cmd == "skills":
        from .skills_system import SkillLifecycleManager, SkillsRegistry
        registry = SkillsRegistry(engine.workspace, workspace_trusted=True); lifecycle = SkillLifecycleManager(engine.workspace)
        action = getattr(parsed_args, "skills_action", None) or "list"
        try:
            if action == "list": payload = {"skills": registry.list_skills(), "promotions": lifecycle.list()}
            elif action == "view": payload = registry.view_skill(parsed_args.name)
            elif action == "promote": payload = lifecycle.promote(parsed_args.name)
            elif action == "validate": payload = lifecycle.validate(parsed_args.name, version=parsed_args.version)
            elif action == "rollback": payload = lifecycle.rollback(parsed_args.name, parsed_args.version)
            elif action == "reuse-check": payload = lifecycle.reuse_decision(parsed_args.name, parsed_args.query, version=parsed_args.version)
            else: payload = lifecycle.set_state(parsed_args.name, "revoked", reason="revoked from CLI")
            print(json.dumps(payload, indent=2)); return 0
        except (KeyError, ValueError) as exc:
            print(json.dumps({"status": "error", "error": str(exc)}, indent=2)); return 1

    if cmd == "backends":
        from .sandbox import backend_status
        print(json.dumps(backend_status(), indent=2)); return 0

    if cmd == "gateway":
        from .local_gateway import GatewayLedger, LocalGateway
        ledger = GatewayLedger(engine.workspace / ".smara" / "gateway.sqlite3")
        action = getattr(parsed_args, "gateway_action", None) or "status"
        if action == "status": print(json.dumps({"pending": ledger.pending(), "database": str(ledger.path)}, indent=2)); return 0
        gateway = LocalGateway(ledger, lambda text, _session: engine.run_turn(text))
        if action == "receive": payload = gateway.receive(channel=parsed_args.channel, sender=parsed_args.sender, text=" ".join(parsed_args.text))
        elif action == "retry": payload = {"results": gateway.retry_pending()}
        else:
            from .local_gateway import WebhookGatewayServer
            server = WebhookGatewayServer(gateway, token=parsed_args.token); server.start(parsed_args.host, parsed_args.port)
            print(json.dumps({"status": "serving", "host": parsed_args.host, "port": parsed_args.port}, indent=2))
            try:
                while True: time.sleep(1)
            except KeyboardInterrupt:
                server.stop()
            return 0
        print(json.dumps(payload, indent=2)); return 0 if payload.get("status", "delivered") != "retry" else 1

    if cmd == "schedule":
        from .local_scheduler import LocalScheduleStore
        schedules = LocalScheduleStore(engine.workspace / ".smara" / "scheduler.sqlite3")
        action = getattr(parsed_args, "schedule_action", None) or "list"
        try:
            if action == "list": payload = schedules.list()
            elif action == "run": payload = schedules.tick(lambda item: engine.run_turn(str(item["payload"].get("prompt") or item["name"])))
            elif action == "add": payload = schedules.add(parsed_args.name, json.loads(parsed_args.payload), parsed_args.interval)
            elif action == "pause": schedules.set_enabled(parsed_args.id, False); payload = {"status": "paused", "id": parsed_args.id}
            elif action == "resume": schedules.set_enabled(parsed_args.id, True); payload = {"status": "resumed", "id": parsed_args.id}
            else: schedules.remove(parsed_args.id); payload = {"status": "removed", "id": parsed_args.id}
            print(json.dumps(payload, indent=2)); return 0
        except (KeyError, ValueError, json.JSONDecodeError) as exc:
            print(json.dumps({"status": "error", "error": str(exc)}, indent=2)); return 1

    if cmd in {"tool", "dynamic-tool"}:
        from .tool_synthesis import DynamicToolSynthesizer
        synthesizer = DynamicToolSynthesizer(engine.workspace)
        tool_cmd = getattr(parsed_args, "tool_subcommand", "list") or "list"

        if tool_cmd == "list":
            tools = synthesizer.list_dynamic_tools()
            print(tui.paint(f"\n🛠️ Smara Dynamic Tool Library ({len(tools)} tools registered):\n", "BOLD"))
            if not tools:
                print(tui.paint("  No dynamic tools synthesized yet. Create one with 'smara tool create <name> --code <code>'\n", "DIM"))
                return 0
            for t in tools:
                print(f"  • {tui.paint(t['name'], 'CYAN')} ({tui.paint(t.get('status', 'active'), 'GREEN')})")
                print(f"    Description: {tui.paint(t.get('description', 'No description'), 'DIM')}")
                print(f"    Path:        {tui.paint(t.get('file', ''), 'DIM')}\n")
            return 0

        if tool_cmd == "create":
            name = parsed_args.name
            code = parsed_args.code
            desc = parsed_args.desc or f"Custom dynamic tool: {name}"
            tui.print_tool_start("dynamic_tool_synthesize", f"Synthesizing & verifying tool '{name}'...")
            try:
                res = synthesizer.synthesize_tool(name=name, description=desc, code=code)
                tui.print_tool_result("dynamic_tool_synthesize", True, f"Saved to {res['path']}")
                print(tui.paint(f"\n✓ Tool '{name}' synthesized, AST-verified, smoke-tested, and registered successfully!\n", "GREEN"))
                return 0
            except Exception as exc:
                tui.print_tool_result("dynamic_tool_synthesize", False, str(exc))
                print(tui.paint(f"\n✗ Tool synthesis failed: {exc}\n", "RED"))
                return 1

        if tool_cmd == "run":
            name = parsed_args.name
            raw_payload = parsed_args.payload or "{}"
            try:
                payload_dict = json.loads(raw_payload)
            except Exception:
                payload_dict = {"input": raw_payload}
            tui.print_tool_start("dynamic_tool_exec", f"Executing dynamic tool '{name}'...")
            res = synthesizer.execute_dynamic_tool(name, payload_dict)
            ok = res.get("status") == "success"
            tui.print_tool_result("dynamic_tool_exec", ok, "Execution finished")
            print(json.dumps(res, indent=2))
            return 0 if ok else 1

    if cmd == "research":
        from .deep_research import DeepResearchEngine
        topic = " ".join(parsed_args.topic)
        print(tui.paint(f"\n🌐 Starting Autonomous Market Intelligence Deep Dive: '{topic}'\n", "BOLD"))
        
        d_engine = DeepResearchEngine(engine.workspace)
        tui.print_thought("Formulating multi-vector research hypotheses and competitive parameters...")
        tui.print_tool_start("deep_research", f"Deep analysis for: {topic}")
        res = d_engine.run_full_pipeline(topic)
        tui.print_tool_result("deep_research", True, f"Synthesized {res['sources_count']} sources")
        
        print(tui.paint(f"\n✓ Market Intelligence Report Compiled Successfully!\n", "GREEN"))
        print(f"  • Deliverable: {tui.paint(res['report_path'], 'BOLD')}")
        print(f"  • Key Tiers:   {len(res['analysis']['competitive_matrix'])} competitive tiers analyzed\n")
        
        print(tui.paint("📋 Executive Summary:", "BOLD"))
        print(f"  {res['analysis']['executive_summary']}\n")
        return 0

    if cmd == "goal" or (cmd == "run" and getattr(parsed_args, "goal", False)):
        from .goal_engine import GoalRunner
        runner = GoalRunner(engine.workspace)
        goal_id = getattr(parsed_args, "goal_id", None) or getattr(parsed_args, "resume", None)
        action = getattr(parsed_args, "goal_action", "run") if cmd == "goal" else "run"

        if action == "list" and not getattr(parsed_args, "objective", None):
            sessions = runner.list_sessions()
            print(tui.paint(f"\n🎯 Smara Autonomous Goal Sessions ({len(sessions)} total):\n", "BOLD"))
            if not sessions:
                print(tui.paint("  No goal sessions found. Start one with 'smara run --goal \"<objective>\"'\n", "DIM"))
                return 0
            for s in sessions:
                st_color = "GREEN" if s["status"] == "completed" else "YELLOW" if s["status"] == "running" else "RED"
                print(f"  • [{tui.paint(s['status'].upper(), st_color)}] {tui.paint(s['goal_id'], 'CYAN')} ({s['steps_completed']}/{s['total_steps']} steps)")
                print(f"    Objective: {tui.paint(s['objective'][:80], 'DIM')}\n")
            return 0

        objective = getattr(parsed_args, "objective", "")
        if isinstance(objective, list):
            objective = " ".join(objective)
        if not objective and not goal_id:
            print(tui.paint("Error: Objective is required. e.g. smara run --goal \"<objective>\"", "RED"))
            return 1

        print(tui.paint(f"\n🎯 Initiating Autonomous Long-Horizon Goal Runner\n", "BOLD"))
        print(f"  • Objective: {tui.paint(objective or str(goal_id), 'CYAN')}\n")

        def on_event(ev_type: str, step, detail: str):
            if ev_type == "step_start":
                tui.print_tool_start(step.capability, f"[{step.id}] {step.title}")
            elif ev_type == "step_complete":
                tui.print_tool_result(step.capability, True, detail)
            elif ev_type == "step_failed":
                tui.print_tool_result(step.capability, False, detail)

        session = runner.execute_goal(
            objective=objective,
            executor_fn=engine.execute_capability,
            on_event=on_event,
            goal_id=goal_id,
        )

        st_color = "GREEN" if session.status == "completed" else "RED"
        print(tui.paint(f"\n🏁 Goal Session {session.goal_id} Finished: {session.status.upper()}\n", st_color))
        print(f"  • Steps Completed: {session.metrics.get('completed_steps', 0)}/{len(session.steps)}")
        if session.final_deliverable:
            print(f"  • Final Deliverable: {tui.paint(session.final_deliverable, 'BOLD')}")
        print()
        return 0 if session.status == "completed" else 1

    # Handle subcommands
    if cmd == "test":
        from .test_fixer import AutonomousTestFixer, PytestRunner
        test_filter = " ".join(parsed_args.filter) if parsed_args.filter else None
        
        tui.print_tool_start("local_terminal", f"Running pytest {test_filter or ''}")
        runner = PytestRunner(engine.workspace)
        result = runner.run(test_filter)
        tui.print_tool_result("local_terminal", result.success, f"{result.passed} passed, {result.failed} failed, {result.errors} errors in {result.duration_seconds:.2f}s")
        
        if result.success:
            print(tui.paint(f"\n✓ All {result.passed} tests passed successfully!\n", "GREEN"))
            return 0
        
        print(tui.paint(f"\n✗ {result.failed} tests failed:\n", "RED"))
        for f in result.failures:
            print(f"  • {f.test_id} ({f.file_path}:{f.line_number or '?'})")
            print(f"    {f.assertion_error}\n")

        if parsed_args.fix:
            print(tui.paint("⚡ Initiating Autonomous Self-Healing Auto-Fixer...\n", "CYAN"))
            fixer = AutonomousTestFixer(engine.workspace)
            fix_res = fixer.auto_fix(test_filter)
            print(tui.paint(f"Status: {fix_res.get('status')}", "BOLD"))
            print(f"Message: {fix_res.get('message')}\n")
            if fix_res.get("status") == "healed":
                return 0
            return 1
        return 1

    if cmd == "refactor":
        instructions = " ".join(parsed_args.instructions)
        _,payload=run_canonical(f"Perform atomic multi-file refactoring: {instructions}. Ensure all changes pass syntax and tests.");print(payload.get("answer", ""));return 0 if payload.get("status")=="completed" else 1

    if cmd == "graph":
        _,payload=run_canonical(f"Inspect the Code Property Graph for the symbol '{parsed_args.symbol}' in our codebase and report its defined methods, callers, and blast radius.");print(payload.get("answer", ""));return 0 if payload.get("status")=="completed" else 1

    if cmd == "search":
        q = " ".join(parsed_args.query)
        _,payload=run_canonical(f"Research and explain {q}. Cite all primary source links.");print(payload.get("answer", ""));return 0 if payload.get("status")=="completed" else 1

    if cmd == "report":
        title = " ".join(parsed_args.title)
        fmt = getattr(parsed_args, "format", "pdf")
        _,payload=run_canonical(f"Create an executive {fmt.upper()} report titled '{title}' saved to reports/audit_summary.{fmt}.");print(payload.get("answer", ""));return 0 if payload.get("status")=="completed" else 1

    if cmd == "ocr":
        import asyncio
        from .ocr_service import SarvamOCRClient, OCRError
        target_file = Path(parsed_args.file).resolve()
        if not target_file.is_file():
            print(tui.paint(f"Error: File not found: {target_file}", "RED"))
            return 1

        tui.print_tool_start("ocr_digitize", f"Digitizing document '{target_file.name}'...")
        client = SarvamOCRClient()
        try:
            res = asyncio.run(client.digitize(target_file, language=parsed_args.lang, output_format=parsed_args.format))
            tui.print_tool_result("ocr_digitize", True, f"Extracted {res.character_count} chars ({res.pages} page(s), provider={res.provider})")

            print(tui.paint(f"\n✓ Digitization Complete ({res.provider.upper()} OCR):\n", "GREEN"))
            print(res.text)
            print()
            if parsed_args.output:
                out_path = Path(parsed_args.output).resolve()
                out_path.parent.mkdir(parents=True, exist_ok=True)
                out_path.write_text(res.text, encoding="utf-8")
                print(tui.paint(f"📄 Saved digitized text to: {out_path}\n", "CYAN"))
            return 0
        except Exception as exc:
            tui.print_tool_result("ocr_digitize", False, str(exc))
            print(tui.paint(f"\n✗ OCR extraction failed: {exc}\n", "RED"))
            return 1

    # Default to Interactive Claude Code REPL
    _interactive_repl(engine,run_canonical)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
