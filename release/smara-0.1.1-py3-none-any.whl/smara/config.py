from __future__ import annotations

import os
from dataclasses import dataclass


def _secret(name: str, default: str = "") -> str:
    """Read an environment secret or a Docker/Kubernetes-style *_FILE value."""
    direct = os.getenv(name)
    if direct:
        return direct
    path = os.getenv(f"{name}_FILE")
    if path:
        try:
            with open(path, "r", encoding="utf-8") as handle:
                value = handle.read().strip()
        except OSError:
            return default
        return value or default
    return default


def _secret_with_fallback(name: str, fallback_name: str = "") -> str:
    """Read a dedicated secret, falling back to one shared provider secret.

    Capture pipelines intentionally reuse the operator's Sarvam key by
    default, while still allowing a deployment to override each capability
    with a separate secret when required.
    """
    value = _secret(name)
    return value or (_secret(fallback_name) if fallback_name else "")


def _env_bool(name: str, default: bool) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _env_int(name: str, default: int, *, minimum: int, maximum: int) -> int:
    try:
        value = int(os.getenv(name, str(default)))
    except (TypeError, ValueError):
        value = default
    return max(minimum, min(maximum, value))


@dataclass(frozen=True)
class Settings:
    database_url: str = os.getenv("SMARA_DATABASE_URL", "")
    database_path: str = os.getenv("SMARA_DATABASE_PATH", "./data/smara.db")
    syntarus_api_key: str = _secret("SYNTARUS_API_KEY")
    syntarus_base_url: str = os.getenv("SYNTARUS_BASE_URL", "https://ai.syntarus.com/v1")
    syntarus_health_url: str = os.getenv("SMARA_SYNTARUS_HEALTH_URL", "")
    dev_mode: bool = os.getenv("SMARA_DEV_MODE", "false").lower() == "true"
    gateway_signing_secret: str = _secret("SMARA_GATEWAY_SIGNING_SECRET")
    control_bridge_secret: str = _secret("SMARA_CONTROL_BRIDGE_SECRET")
    # Native Smara identity.  In production this points at the existing
    # account database so account ids and memory namespaces survive the
    # Memento -> Smara cutover.  It is deliberately separate from the task
    # database setting so a deployment cannot accidentally create a second
    # identity store.
    accounts_database_url: str = os.getenv("SMARA_ACCOUNTS_DATABASE_URL", os.getenv("ACCOUNTS_DB_URL", ""))
    session_secret: str = _secret("SMARA_SESSION_SECRET")
    session_ttl_days: int = int(os.getenv("SMARA_SESSION_TTL_DAYS", "30"))
    auth_cookie_name: str = os.getenv("SMARA_AUTH_COOKIE_NAME", "smara_session")
    # The operator console is deliberately separate from ordinary account
    # sessions. A normal signed-in user can use Smara, but cannot enumerate
    # other accounts or operational data unless this secret is provisioned.
    operator_secret: str = _secret("SMARA_OPERATOR_SECRET")
    operator_cookie_name: str = os.getenv("SMARA_OPERATOR_COOKIE_NAME", "smara_operator")
    operator_session_hours: int = int(os.getenv("SMARA_OPERATOR_SESSION_HOURS", "12"))
    internal_token: str = _secret("SMARA_INTERNAL_TOKEN")
    allowed_origins: str = os.getenv(
        "SMARA_ALLOWED_ORIGINS",
        "https://ai.syntarus.com",
    )
    integration_master_key: str = _secret("SMARA_INTEGRATION_MASTER_KEY")
    integration_master_keys: str = _secret("SMARA_INTEGRATION_MASTER_KEYS", _secret("SMARA_INTEGRATION_MASTER_KEY"))
    # Personal-account integrations (Gmail, Calendar, Drive, GitHub, Telegram)
    # are disabled on the hosted control plane by default. User credentials
    # and browser sessions belong on the paired local device; the VM should
    # only run operator-owned LLM/public-research services and coordination.
    hosted_user_integrations_enabled: bool = os.getenv("SMARA_HOSTED_USER_INTEGRATIONS_ENABLED", "false").lower() == "true"
    public_base_url: str = os.getenv("SMARA_PUBLIC_BASE_URL", "http://127.0.0.1:8080")
    google_client_id: str = os.getenv("SMARA_GOOGLE_CLIENT_ID", "")
    google_client_secret: str = _secret("SMARA_GOOGLE_CLIENT_SECRET")
    telegram_bot_token: str = _secret("SMARA_TELEGRAM_BOT_TOKEN", _secret("TELEGRAM_BOT_TOKEN"))
    telegram_bot_url: str = os.getenv("SMARA_TELEGRAM_BOT_URL", os.getenv("TELEGRAM_BOT_URL", ""))
    telegram_chat_url: str = os.getenv("SMARA_TELEGRAM_CHAT_URL", "http://api:8080")
    github_client_id: str = os.getenv("SMARA_GITHUB_CLIENT_ID", "")
    github_client_secret: str = _secret("SMARA_GITHUB_CLIENT_SECRET")
    vapid_public_key: str = os.getenv("SMARA_VAPID_PUBLIC_KEY", "")
    vapid_private_key: str = _secret("SMARA_VAPID_PRIVATE_KEY")
    vapid_subject: str = os.getenv("SMARA_VAPID_SUBJECT", "mailto:admin@example.com")
    rate_limit_per_minute: int = int(os.getenv("SMARA_RATE_LIMIT_PER_MINUTE", "120"))
    sentry_dsn: str = _secret("SMARA_SENTRY_DSN")
    redis_url: str = os.getenv("SMARA_REDIS_URL", "")
    llm_base_url: str = os.getenv("SMARA_LLM_BASE_URL", "")
    llm_api_key: str = _secret("SMARA_LLM_API_KEY")
    llm_model: str = os.getenv("SMARA_LLM_MODEL", "")
    llm_provider: str = os.getenv("SMARA_LLM_PROVIDER", "configured model provider")
    llm_profiles: str = os.getenv("SMARA_LLM_PROFILES", "")
    llm_default_profile: str = os.getenv("SMARA_LLM_DEFAULT_PROFILE", "")
    plugin_manifests: str = os.getenv("SMARA_PLUGIN_MANIFESTS", "")
    research_synthesis_enabled: bool = os.getenv("SMARA_RESEARCH_SYNTHESIS_ENABLED", "false").lower() == "true"
    cli_token_secret: str = _secret("SMARA_CLI_TOKEN_SECRET")
    cli_token_ttl_days: int = int(os.getenv("SMARA_CLI_TOKEN_TTL_DAYS", "30"))
    search_provider: str = os.getenv("SMARA_SEARCH_PROVIDER", "brave")
    search_api_key: str = _secret("SMARA_SEARCH_API_KEY")
    search_url: str = os.getenv("SMARA_SEARCH_URL", "")
    # Optional second provider used only when the primary provider is
    # unavailable or returns too few usable leads.  Keeping this separate
    # from the primary key lets operators run a real fallback without ever
    # sending credentials to the browser.
    search_fallback_provider: str = os.getenv("SMARA_SEARCH_FALLBACK_PROVIDER", "")
    search_fallback_api_key: str = _secret("SMARA_SEARCH_FALLBACK_API_KEY")
    search_fallback_url: str = os.getenv("SMARA_SEARCH_FALLBACK_URL", "")
    # Advanced Tavily retrieval returns stronger page-level leads for research
    # while remaining provider-neutral. Operators may choose "basic" when
    # latency/cost matters more than recall.
    search_depth: str = os.getenv("SMARA_SEARCH_DEPTH", "advanced").lower()
    search_timeout_seconds: float = float(os.getenv("SMARA_SEARCH_TIMEOUT_SECONDS", "12"))
    # Keep provider calls bounded.  Several search services throttle bursts;
    # deep research should trade a little latency for a complete, diverse
    # evidence set instead of silently losing most concurrent searches.
    search_max_concurrency: int = int(os.getenv("SMARA_SEARCH_MAX_CONCURRENCY", "2"))
    research_allowed_domains: str = os.getenv("SMARA_RESEARCH_ALLOWED_DOMAINS", "")
    research_blocked_domains: str = os.getenv("SMARA_RESEARCH_BLOCKED_DOMAINS", "")
    capture_transcription_base_url: str = os.getenv("SMARA_CAPTURE_TRANSCRIPTION_BASE_URL", "")
    capture_transcription_api_key: str = _secret_with_fallback("SMARA_CAPTURE_TRANSCRIPTION_API_KEY", "SMARA_SARVAM_KEY")
    capture_transcription_model: str = os.getenv("SMARA_CAPTURE_TRANSCRIPTION_MODEL", "")
    capture_transcription_auth_header: str = os.getenv("SMARA_CAPTURE_TRANSCRIPTION_AUTH_HEADER", "Authorization")
    capture_vision_base_url: str = os.getenv("SMARA_CAPTURE_VISION_BASE_URL", "")
    capture_vision_api_key: str = _secret_with_fallback("SMARA_CAPTURE_VISION_API_KEY", "SMARA_SARVAM_KEY")
    capture_vision_model: str = os.getenv("SMARA_CAPTURE_VISION_MODEL", "")
    capture_vision_auth_header: str = os.getenv("SMARA_CAPTURE_VISION_AUTH_HEADER", "Authorization")
    # Sarvam Document AI is an asynchronous OCR service, not a chat model.
    # Keep it on its own bounded capture path rather than exposing it as a
    # selectable chat profile.
    capture_ocr_base_url: str = os.getenv("SMARA_CAPTURE_OCR_BASE_URL", "")
    capture_ocr_api_key: str = _secret_with_fallback("SMARA_CAPTURE_OCR_API_KEY", "SMARA_SARVAM_KEY")
    capture_ocr_model: str = os.getenv("SMARA_CAPTURE_OCR_MODEL", "sarvam-vision-1.5")
    capture_ocr_language: str = os.getenv("SMARA_CAPTURE_OCR_LANGUAGE", "en-IN")
    capture_ocr_auth_header: str = os.getenv("SMARA_CAPTURE_OCR_AUTH_HEADER", "api-subscription-key")
    # Disabled until a separately isolated sandbox service is deployed.
    sandbox_enabled: bool = os.getenv("SMARA_SANDBOX_ENABLED", "false").lower() == "true"
    sandbox_url: str = os.getenv("SMARA_SANDBOX_URL", "")
    sandbox_token: str = _secret("SMARA_SANDBOX_TOKEN")
    # Performance rollout switches. They are intentionally environment-only
    # so an operator can roll back one optimization without a code deploy.
    fast_routing_enabled: bool = _env_bool("SMARA_FAST_ROUTING_ENABLED", True)
    pooled_resources_enabled: bool = _env_bool("SMARA_POOLED_RESOURCES_ENABLED", True)
    work_signals_enabled: bool = _env_bool("SMARA_WORK_SIGNALS_ENABLED", True)
    desktop_long_poll_enabled: bool = _env_bool("SMARA_DESKTOP_LONG_POLL_ENABLED", True)
    shadow_routing_enabled: bool = _env_bool("SMARA_SHADOW_ROUTING_ENABLED", False)
    worker_concurrency: int = _env_int("SMARA_WORKER_CONCURRENCY", 4, minimum=1, maximum=8)


settings = Settings()
